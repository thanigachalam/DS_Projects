#importing Uber Request Data.csv file to variable
uber_request_dataset <- read.csv("Uber Request Data.csv")

#Cleaning up the date formate for Request.timestamp column in uber data set
#install.packages("lubridate")
library(lubridate)
uber_request_dataset$Request.timestamp<-parse_date_time(uber_request_dataset$Request.timestamp,orders=c("%d-%m-%Y %H:%M:%S","%d/%m/%Y %H:%M"), exact = TRUE)

#Cleaning up the date formate for Drop.timestamp column in uber data set
uber_request_dataset$Drop.timestamp<-parse_date_time(uber_request_dataset$Drop.timestamp,orders=c("%d-%m-%Y %H:%M:%S","%d/%m/%Y %H:%M"), exact = TRUE)

#-------------------------------------------------------------------
#                     Creating derived columns based on Requested Date
#-------------------------------------------------------------------
# creating date column
uber_request_dataset$Request.date <- as.Date(uber_request_dataset$Request.timestamp, format = "%y/%m/%d")
# creating day column
uber_request_dataset$Request.day <- format(uber_request_dataset$Request.date, '%d') #day
# creating month number column
uber_request_dataset$Request.month <- format(uber_request_dataset$Request.date, '%m') #month number
# creating year column
uber_request_dataset$Request.year <- format(uber_request_dataset$Request.date, '%Y') #year


# creating hour column
uber_request_dataset$Request.hr <- hour(uber_request_dataset$Request.timestamp)
#min
uber_request_dataset$Request.min <- minute(uber_request_dataset$Request.timestamp)
# creating date name column for Request date.
uber_request_dataset$Request.dayname <- format(uber_request_dataset$Request.date, '%A') #day
# creating month name columne for Request date.
uber_request_dataset$Request.monthname <- format(uber_request_dataset$Request.date, '%B') #month number


#-------------------------------------------------------------------------------

# Creating derived column to identify the Drop Point
library(dplyr)
library(plyr)
uber_request_dataset %>%
  plyr::mutate(Drop.point =
                 dplyr::case_when(Pickup.point == "Airport"   ~ "City",
                                  Pickup.point == "City"   ~ "Airport",
                                  TRUE                     ~ "undetermined"
                 )) -> uber_request_dataset
# creating time slots columns from Request timestamp.
uber_request_dataset %>%
  plyr::mutate(Request.time.slot =
                 dplyr::case_when(Request.hr >= 1 & Request.hr <= 5   ~ "1-5 [Early morning]",
                                  Request.hr == 6   ~ "6 [Dawn]",
                                  Request.hr >= 7 & Request.hr <= 9   ~ "7-9 [Morning]",
                                  Request.hr >= 10  & Request.hr < 12   ~ "10-11 [Mid-morning]",
                                  Request.hr >= 12 & Request.hr <= 13   ~ "12-13 [Noon]",
                                  Request.hr >= 14 & Request.hr < 16   ~ "14-15 [Afternoon]",
                                  Request.hr >= 16 & Request.hr < 18   ~ "16-17 [Evening]",
                                  Request.hr == 18   ~ "18 [Dusk]",
                                  Request.hr >= 19 & Request.hr < 21   ~ "19-20 [Late Evening]",
                                  Request.hr >= 21 & Request.hr <= 23   ~ "21-23 [Night]",
                                  Request.hr == 0   ~ "0 [Mid-night]",
                                  TRUE                     ~ "undetermined"
                 )) -> uber_request_dataset

uber_request_dataset$Request.time.slot <- factor(uber_request_dataset$Request.time.slot, levels=c("0 [Mid-night]","1-5 [Early morning]","6 [Dawn]", "7-9 [Morning]","10-11 [Mid-morning]", "12-13 [Noon]", "14-15 [Afternoon]","16-17 [Evening]", "18 [Dusk]", "19-20 [Late Evening]", "21-23 [Night]"))

#---------------------------------------------------------------------------------

#library(dplyr)
#install.packages('plyr')
library(plyr)

#--------------------------------------------------------------------------------
# Trip status count by request hour
uber_trip_status_count <- count(uber_request_dataset, c("Request.hr","Status"))
uber_trip_status_and_pickup_point_count <- count(uber_request_dataset, c("Request.hr","Status", "Pickup.point"))
# Trip status count by "Status","Request.hr","Pickup.point","Drop.point","Request.time.slot"
uber_trip_status_count_detail <- count(uber_request_dataset, c("Status","Request.hr","Pickup.point","Drop.point","Request.time.slot"))


#renaming count column name
colnames(uber_trip_status_count)[colnames(uber_trip_status_count)=="freq"] <- "count_value"
colnames(uber_trip_status_and_pickup_point_count)[colnames(uber_trip_status_and_pickup_point_count)=="freq"] <- "count_value"
colnames(uber_trip_status_count_detail)[colnames(uber_trip_status_count_detail)=="freq"] <- "count_value"
#
#--------------------------------------------------------------------------------

#------------------------------------------------------------------------------
#------------------------------------------------------------------------------
#                     Hourly Frequency Plot to Understand the Dataset
#------------------------------------------------------------------------------
#------------------------------------------------------------------------------

library(ggplot2)
theme_set(theme_classic())
# Histogram on a date or day (Numeric) Variable
#------------------------------------------
#plot by trip status accross dataset.
# -----------------------------------------
#Plots to visualise the frequency of the Trip Requests
By_Trip_Status <- ggplot(data = uber_trip_status_count, aes(x = factor(uber_trip_status_count$Request.hr), y = uber_trip_status_count$count_value)) + 
  geom_histogram(stat = "identity", aes(fill = uber_trip_status_count$Status), binwidth = .1, size=.1) + 
  labs(title="Plots to visualise the frequency of the Trip Requests"
       , subtitle="Trip status accross dataset"
       , x = "Time in Hour" 
       , y = "Trip Request Count"
       , fill='By Trip Status') 

#---------------------------------------------------------------------------------
#Plots to visualise the frequency of the Trip Requests from Airport
uber_trip_status_and_pickup_point_Airport <- dplyr::filter(uber_trip_status_and_pickup_point_count, uber_trip_status_and_pickup_point_count$Pickup.point == "Airport")

# Plots to visualise the frequency of the Trip Requests from Airport
Trip_request_from_Airport <- ggplot(data = uber_trip_status_and_pickup_point_Airport, aes(x = factor(uber_trip_status_and_pickup_point_Airport$Request.hr), y = uber_trip_status_and_pickup_point_Airport$count_value)) + 
  geom_histogram(stat = "identity", aes(fill = uber_trip_status_and_pickup_point_Airport$Status), binwidth = .1, size=.1) + 
  labs(title="Plots to visualise the frequency of the Trip Requests from Airport"
       , subtitle="Trip status accross dataset"
       , x = "Time in Hour" 
       , y = "Trip Request Count"
       , fill='By Trip Status') 

# Plots to visualise the frequency of the Trip Requests from City
#---------------------------------------------------------------------------------
uber_trip_status_and_pickup_point_City <- dplyr::filter(uber_trip_status_and_pickup_point_count, uber_trip_status_and_pickup_point_count$Pickup.point == "City")

Trip_request_from_City <- ggplot(data = uber_trip_status_and_pickup_point_City, aes(x = factor(uber_trip_status_and_pickup_point_City$Request.hr), y = uber_trip_status_and_pickup_point_City$count_value)) + 
  geom_histogram(stat = "identity", aes(fill = uber_trip_status_and_pickup_point_City$Status), binwidth = .1, size=.1) + 
  labs(title="Plots to visualise the frequency of the Trip Requests from City"
       , subtitle="Trip status accross dataset"
       , x = "Time in Hour" 
       , y = "Trip Request Count"
       , fill='By Trip Status') 

#Hourly Frequency Plot to Understand the Dataset
#This depicts how the Trip Request and Responses looks across each hour of the given data.
#--------------------------------------------------------------
library(gridExtra)

grid.arrange( By_Trip_Status,
              Trip_request_from_Airport,
              Trip_request_from_City,
              nrow=3)
#dev.off()

#------------------------------------------------------------------------------
#               1.Visually identify the most pressing problems for Uber.
#---------------------------------------------------------------------------------
# The above plot display overall Trip status request count has been displayed for
# hourly and this section gives details of each status how the trend is wary every hour.

#only for No cars available
library(dplyr)
#This frequency plot to visualise 'no cars available' from city to airport
# Assuming the data shared is only the pickup and drop will be city to airport or airport to city
uber_status_no_cars_available_from_city_to_airport <- dplyr::filter(uber_trip_status_count_detail, uber_trip_status_count_detail$Status == "No Cars Available")
#write.csv(uber_status_no_cars_available_from_city_to_airport,"uber_status_no_cars_available_from_city_to_airport.csv")
uber_status_no_cars_available_from_city_to_airport <- dplyr::filter(uber_status_no_cars_available_from_city_to_airport, uber_status_no_cars_available_from_city_to_airport$Pickup.point =="City")

uber_status_no_cars_available_from_city_to_airport_timeslot <- ggplot(data = uber_status_no_cars_available_from_city_to_airport, 
                                                     aes(x = factor(uber_status_no_cars_available_from_city_to_airport$Request.time.slot),
                                                         y = count_value)
) + 
  geom_bar(stat = "identity", position = "dodge", aes(fill = uber_status_no_cars_available_from_city_to_airport$Pickup.point)) + 
  scale_fill_manual("legend", values = c("City" = "orange")) + 
  labs(title="This frequency plot to visualise 'no cars available' from city to airport"
       , x = "Time Slots" 
       , y = "# of 'no cars available"
       , fill='Pickup Point') 

uber_status_no_cars_available_from_city_to_airport_timeslot

#----------------------------------------- 'no cars available' from city to airport" end
#------------------------------------------------------------------------------
#------------------------------------------------------------------------------
#               Chart 3.b
#------------------------------------------------------------------------------
#------------------------------------------------------------------------------
#---------------------------------------------------------------------------------
#----------------------------------------- 'no cars available' from airport to city" started ---------------------#

uber_status_no_cars_available_from_airport_to_city <- dplyr::filter(uber_trip_status_count_detail, uber_trip_status_count_detail$Status == "No Cars Available")
uber_status_no_cars_available_from_airport_to_city <- dplyr::filter(uber_status_no_cars_available_from_airport_to_city, uber_status_no_cars_available_from_airport_to_city$Pickup.point =="Airport")

uber_status_no_cars_available_from_airport_to_city_timeslot <- ggplot(data = uber_status_no_cars_available_from_airport_to_city, 
                                                                      aes(x = factor(uber_status_no_cars_available_from_airport_to_city$Request.time.slot),
                                                                          y = count_value)
) + 
  geom_bar(stat = "identity", position = "dodge", aes(fill = uber_status_no_cars_available_from_airport_to_city$Pickup.point)) + 
  scale_fill_manual("legend", values = c("Airport" = "blue")) + 
  labs(title="This frequency plot to visualise 'no cars available' from airport to city"
       , x = "Time Slots" 
       , y = "# of 'no cars available"
       , fill='Pickup Point')

uber_status_no_cars_available_from_airport_to_city_timeslot

#This frequency plot to visualise 'no cars available' from city to airport vs airport to city
uber_status_no_cars_available_dataset <- dplyr::filter(uber_trip_status_count_detail, uber_trip_status_count_detail$Status == "No Cars Available")
######### uber_status_no_cars_available_dataset$Request.time.slot <- factor(uber_status_no_cars_available_dataset$Request.time.slot, levels=c("0 [Mid-night]","1-5 [Early morning]","6 [Dawn]", "7-9 [Morning]","10-11 [Mid-morning]", "12-13 [Noon]", "14-15 [Afternoon]","16-17 [Evening]", "18 [Dusk]", "19-20 [Late Evening]", "21-23 [Night]"))
No_Cars_Available_vs_pickup_point_timeslot <- ggplot(data = uber_status_no_cars_available_dataset, 
       aes(x = factor(uber_status_no_cars_available_dataset$Request.time.slot),
           y = count_value)
       ) + 
  geom_bar(stat = "identity", position = "dodge", aes(fill = uber_status_no_cars_available_dataset$Pickup.point)) + 
  scale_fill_manual("legend", values = c("City" = "orange", "Airport" = "blue")) + 
  labs(title="This frequency plot to visualise 'no cars available' from city to airport vs airport to city "
       , subtitle="Trip status: 'No cars available' accross dataset Airport Vs City"
       , x = "Time Slots" 
       , y = "# of 'no cars available"
       , fill='Pickup Point')

No_Cars_Available_vs_pickup_point_timeslot


library(gridExtra)

grid.arrange( uber_status_no_cars_available_from_city_to_airport_timeslot,
              uber_status_no_cars_available_from_airport_to_city_timeslot,
              No_Cars_Available_vs_pickup_point_timeslot,
              nrow=3)
#dev.off()
#-----------------------------------------------------
library(dplyr)
#1.b.1 This bar chart to visualize the 'Cancelled' statuses from city to airport. As part of this, we infer that
#cancellation is significant in the mornings with time ranging between 7 am and 9 am.
# Assuming the data shared is only the pickup and drop will be city to airport or airport to city
uber_status_no_request_cancelled_from_city_to_airport <- dplyr::filter(uber_trip_status_count_detail, uber_trip_status_count_detail$Status == "Cancelled")
#write.csv(uber_status_no_request_cancelled_from_city_to_airport,"uber_status_no_request_cancelled_from_city_to_airport.csv")
uber_status_no_request_cancelled_from_city_to_airport <- dplyr::filter(uber_status_no_request_cancelled_from_city_to_airport, uber_status_no_request_cancelled_from_city_to_airport$Pickup.point =="City")

uber_status_no_request_cancelled_from_city_to_airport_timeslot <- ggplot(data = uber_status_no_request_cancelled_from_city_to_airport, 
                                                                      aes(x = factor(uber_status_no_request_cancelled_from_city_to_airport$Request.time.slot),
                                                                          y = count_value)
) + 
  geom_bar(stat = "identity", position = "dodge", aes(fill = uber_status_no_request_cancelled_from_city_to_airport$Pickup.point)) + 
  scale_fill_manual("legend", values = c("City" = "orange")) + 
  labs(title="This frequency plot to visualise 'cancelled' from city to airport"
       , x = "Time Slots" 
       , y = "# of request 'cancelled '"
       , fill='Pickup Point') 

uber_status_no_request_cancelled_from_city_to_airport_timeslot
#-------------------------------------------------------------------
uber_status_no_request_cancelled_from_airport_to_city <- dplyr::filter(uber_trip_status_count_detail, uber_trip_status_count_detail$Status == "Cancelled")
uber_status_no_request_cancelled_from_airport_to_city <- dplyr::filter(uber_status_no_request_cancelled_from_airport_to_city, uber_status_no_request_cancelled_from_airport_to_city$Pickup.point =="Airport")

uber_status_no_request_cancelled_from_airport_to_city_timeslot <- ggplot(data = uber_status_no_request_cancelled_from_airport_to_city, 
                                                                      aes(x = factor(uber_status_no_request_cancelled_from_airport_to_city$Request.time.slot),
                                                                          y = count_value)
) + 
  geom_bar(stat = "identity", position = "dodge", aes(fill = uber_status_no_request_cancelled_from_airport_to_city$Pickup.point)) + 
  scale_fill_manual("legend", values = c("Airport" = "blue")) + 
  labs(title="This frequency plot to visualise 'cancelled' request from airport to city"
       , x = "Time Slots" 
       , y = "# of request 'cancelled '"
       , fill='Pickup Point')

uber_status_no_request_cancelled_from_airport_to_city_timeslot
#-----------------------------------------------------------------
uber_status_no_request_cancelled_City_vs_Airport <- dplyr::filter(uber_trip_status_count_detail, uber_trip_status_count_detail$Status == "Cancelled")

uber_status_no_request_cancelled_City_vs_Airport_timeslot <- ggplot(data = uber_status_no_request_cancelled_City_vs_Airport, 
                                                     aes(x = factor(uber_status_no_request_cancelled_City_vs_Airport$Request.time.slot),
                                                         y = count_value)
) + 
  geom_bar(stat = "identity", position = "dodge", aes(fill = uber_status_no_request_cancelled_City_vs_Airport$Pickup.point)) + 
  scale_fill_manual("legend", values = c("City" = "orange", "Airport" = "blue")) + 
  labs(title="This frequency plot to visualise 'Cancelled' from city to airport vs airport to city "
       , subtitle="Trip status: 'Cancelled' accross dataset"
       , x = "Time Slots" 
       , y = "# of request 'cancelled '"
       , fill='Pickup Point')
#This frequency plot to visualise 'Cancelled' from city to airport vs airport to city
uber_status_no_request_cancelled_City_vs_Airport_timeslot


library(gridExtra)
#This frequency plot to visualise 'Cancelled' from city to airport vs airport to city
grid.arrange( uber_status_no_request_cancelled_from_city_to_airport_timeslot,
              uber_status_no_request_cancelled_from_airport_to_city_timeslot,
              uber_status_no_request_cancelled_City_vs_Airport_timeslot,
              nrow=3)
#dev.off()

#------------------------------------------------------
head(uber_trip_status_count_detail)
#--------------------------------------------------- 2

library(ggplot2)
theme_set(theme_classic())
#2. Find out the gap between supply and demand and show the same using plots.
# Find the time slots when the highest gap exists
# Find the types of requests (city-airport or airport-city) for which the gap 
# is the most severe in the identified time slots

#Trip type of request from airport to city by time slots
uber_trip_type_of_request_Airport_to_city <- dplyr::filter(uber_trip_status_count_detail, uber_trip_status_count_detail$Pickup.point == "Airport")

# From pickup point airport how the trip status looks.
Trip_request_from_Airport_timeslot <- ggplot(data = uber_trip_type_of_request_Airport_to_city, aes(x = factor(uber_trip_type_of_request_Airport_to_city$Request.time.slot), y = uber_trip_type_of_request_Airport_to_city$count_value)) + 
  geom_histogram(stat = "identity", aes(fill = uber_trip_type_of_request_Airport_to_city$Status), binwidth = .1, size=.1) + 
  labs(title="Type of request for Airport to City"
       , subtitle="Trip request accross dataset"
       , x = "Time Slots" 
       , y = "Trip Request Count"
       , fill='Type of Request') 

Trip_request_from_Airport_timeslot

#---------------------------------------------------------------------------------
#Trip type of request from airport to city by time slots
uber_trip_type_of_request_city_to_Airport <- dplyr::filter(uber_trip_status_count_detail, uber_trip_status_count_detail$Pickup.point == "City")

# From pickup point airport how the trip status looks.
Trip_request_from_City_timeslot <- ggplot(data = uber_trip_type_of_request_city_to_Airport, aes(x = factor(uber_trip_type_of_request_city_to_Airport$Request.time.slot), y = uber_trip_type_of_request_city_to_Airport$count_value)) + 
  geom_histogram(stat = "identity", aes(fill = uber_trip_type_of_request_city_to_Airport$Status), binwidth = .1, size=.1) + 
  labs(title="Type of request for City to Airport"
       , subtitle="Trip request accross dataset"
       , x = "Time Slots" 
       , y = "Trip Request Count"
       , fill='Type of Request') 

Trip_request_from_City_timeslot

#-----------------------------------------------------
#-----------------  completed Trips
#-----------------------------------------------------

#Find the Trip completed between Pickup point
uber_trip_completed_data <- dplyr::filter(uber_trip_status_count_detail, uber_trip_status_count_detail$Status == "Trip Completed")
#head(uber_trip_completed_data)
# Identifying where we can see more dropping is happening compare to City vs Airport
most_uber_trip_dropping <- ggplot(data = uber_trip_completed_data, 
                                  aes(x = factor(uber_trip_completed_data$Request.time.slot), 
                                      y = uber_trip_completed_data$count_value)) + 
  geom_bar(stat = "identity", position = "dodge", aes(fill = uber_trip_completed_data$Drop.point)) + 
  #geom_histogram(stat = "identity", aes(fill = uber_trip_completed_data$Drop.point), binwidth = .1, size=.1) + 
  labs(title="This plot explains where more/less dropping is happening between City and Airport"
       , subtitle="Trip Completed between Airport Vs City based on Drop Point"
       , x = "Time Slots" 
       , y = "No of Trips Completed"
       , fill='Drop Point') 

most_uber_trip_dropping

#------------------------------------------------------

#Identifying the pickup point and Time slots when and where
most_uber_trip_pickup <- ggplot(data = uber_trip_completed_data, 
                                aes(x = factor(uber_trip_completed_data$Request.time.slot), 
                                    y = uber_trip_completed_data$count_value)
) + 
  geom_bar(stat = "identity",position = "dodge", aes(fill = uber_trip_completed_data$Pickup.point)) + 
  labs(title="This plot explains where more/less pickup is raising between City and Airport"
       , subtitle="Trip Completed between Airport Vs City based on Pickup Point"
       , x = "Time Slots" 
       , y = "No of Trips Completed"
       , fill='Pickup Point')

most_uber_trip_pickup

#----------------------------------------------------------------------
# Total Request
Total_Request <- ggplot(data = uber_trip_status_count_detail, 
                        aes(x = factor(uber_trip_status_count_detail$Request.time.slot), 
                            y = uber_trip_status_count_detail$count_value)
) + 
  geom_bar(stat = "identity",position = "dodge", aes(fill = uber_trip_status_count_detail$Pickup.point)) + 
  labs(title="This plot explains Total Request against City vs Airport"
       , subtitle="In this complete Trip Request details has been considered."
       , x = "Time Slots" 
       , y = "Total No of Request Made"
       , fill='Pickup Point')

Total_Request


#------------------------------------------------------
#Find out the gap between supply and demand and show the same using plots.

#Find the time slots when the highest gap exists
library(gridExtra)

grid.arrange( most_uber_trip_dropping,
              most_uber_trip_pickup,
              Total_Request,
              nrow=3)
#dev.off()

#-----------------------------------------------------------------------------
