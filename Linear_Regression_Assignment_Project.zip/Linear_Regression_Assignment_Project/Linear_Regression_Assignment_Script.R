carprice_assignment <- read.csv("CarPrice_Assignment.csv")
#--------------------------------------------------------------------------
#--------------------- Linear Regression Assignment -----------------------
#--------------------------------------------------------------------------
#.....................................................
#Required Packages
#.....................................................
#Validating the required packages and installing if any package is not available
list.of.packages <- c("ggplot2", "ggpubr","gridExtra","ggthemes","corrgram","MASS","car","PerformanceAnalytics","dummies","psych")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)

#install.packages("corrgram")
library(ggplot2)
library(ggpubr)
library(plyr)
library(dplyr)
library(tidyr)
library(stringr)
library(gridExtra)
library(ggthemes)
#install.packages("MASS") #for StepAIC
#install.packages("car") #for VIF
#install.packages("PerformanceAnalytics")
#install.packages("dummies")

#--------------------------------------------------------------------------------------------------------
#Creating a Derived column Company Name from CarName
#--------------------------------------------------------------------------------------------------------
library(tidyr)
#converting carname column to upper case
carprice_assignment$CarName <- toupper(carprice_assignment$CarName)

#Extract the primary sector of each category list from the category_list column
carprice_assignment <- tidyr::extract(carprice_assignment, CarName, c("company_name") #, "sub_category1", "sub_category2","sub_category3"
                                      ,remove = F,  "([[:alnum:]]+)") #([[|^|]]+)|([[^|]]+)|([[^|]]+)

#Cleaning up the following Data
#"MAXDA"      "MAZDA" 
#"TOYOTA"     "TOYOUTA"
#"Nissan"     "nissan"
#"PORSCHE"    "PORCSHCE"
#"VOKSWAGEN"  "VOLKSWAGEN" "VW"

#replacing actual name
carprice_assignment$company_name <- replace(
  carprice_assignment$company_name,
  carprice_assignment$company_name == "MAXDA", "MAZDA")

carprice_assignment$company_name <- replace(
  carprice_assignment$company_name,
  carprice_assignment$company_name == "TOYOUTA", "TOYOTA")

carprice_assignment$company_name <- replace(
  carprice_assignment$company_name,
  carprice_assignment$company_name == "PORCSHCE", "PORSCHE")

carprice_assignment$company_name <- replace(
  carprice_assignment$company_name,
  carprice_assignment$company_name == "VOKSWAGEN", "VOLKSWAGEN")

carprice_assignment$company_name <- replace(
  carprice_assignment$company_name,
  carprice_assignment$company_name == "VW", "VOLKSWAGEN")

carprice_assignment$company_name <- replace(
  carprice_assignment$company_name,
  carprice_assignment$company_name == "ALFA", "ALFA-ROMEO")

#-----------------------------------------------------------------
#creating Dummy variables.
#------------------------------------------------------------------
library(dummies)
carprice_assignment <- cbind(carprice_assignment, dummy(carprice_assignment$fueltype, sep = "_fueltype_"))
carprice_assignment <- cbind(carprice_assignment, dummy(carprice_assignment$aspiration, sep = "_aspiration_"))
carprice_assignment <- cbind(carprice_assignment, dummy(carprice_assignment$doornumber, sep = "_doornumber_"))
carprice_assignment <- cbind(carprice_assignment, dummy(carprice_assignment$carbody, sep = "_carbody_"))
carprice_assignment <- cbind(carprice_assignment, dummy(carprice_assignment$drivewheel, sep = "_drivewheel_"))
carprice_assignment <- cbind(carprice_assignment, dummy(carprice_assignment$enginelocation, sep = "_enginelocation_"))
carprice_assignment <- cbind(carprice_assignment, dummy(carprice_assignment$enginetype, sep = "_enginetype_"))
carprice_assignment <- cbind(carprice_assignment, dummy(carprice_assignment$cylindernumber, sep = "_cylindernumber_"))
carprice_assignment <- cbind(carprice_assignment, dummy(carprice_assignment$fuelsystem, sep = "_fuelsystem_"))
carprice_assignment <- cbind(carprice_assignment, dummy(carprice_assignment$symboling, sep = "_symboling_"))
carprice_assignment <- cbind(carprice_assignment, dummy(carprice_assignment$company_name, sep = "_"))

#------------------------------------------------------------------
# EDA Analysis
#------------------------------------------------------------------
library(ggplot2)
library(ggpubr)

#Analysis on Symboling data
symboling_data <- ggplot(data = carprice_assignment, aes(x = factor(carprice_assignment$symboling)))

#Symboling %
symboling_percentage_plot <- symboling_data +
  geom_bar(aes(y = (..count..)/sum(..count..)),fill = "#0073C2FF") +
  geom_text(aes(y = ((..count..)/sum(..count..)), label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.25) +
  labs(title="Symboling %"
       , x = "Symboling (+3 indicates that the auto is risky, -3 that it is probably pretty safe)" 
       , y = "Number of Symboling") + theme_pubclean()

symboling_percentage_plot
#...........................................................................
#Validating Correlation betwen enginelocation,weelbase,carlength,carwidth,carheight.
library(psych)
pairs.panels(carprice_assignment[10:14])  # select columns 1-4
#...........................................................................
#https://www.statmethods.net/advgraphs/correlograms.html

library(corrgram)
library(psych)
pairs.panels(carprice_assignment[5:12])  # select columns 5-12

#-------------------------------------------------------------------
#Average Car Price by Company
ggplot(data = carprice_assignment,
       aes(x = carprice_assignment$company_name), y = mean(complete_titanic_ds$Fare)) + #(..count..)
  geom_bar() + 
  labs(title="Average Car Price by Company"
       , x = "Company Name" 
       , y = "Average Price")+ theme(axis.text.x = element_text(angle = 90, hjust = 1, size = 11))
#------------------------------------------------------------------
#Average Car Price distribution on symboling by Company
#Boxplot explains how the distribution of Average Price accross the Dataset
ggplot(data = carprice_assignment, aes(x = factor(carprice_assignment$symboling),y = (carprice_assignment$price)))+
  geom_boxplot() + facet_wrap(~factor(carprice_assignment$company_name)) +
  labs(title="Average Car Price by Company"
       , subtitle="Boxplot explains how the distribution of Average Price accross the Dataset"
       , x = "symboling" 
       , y = "Average Price") + theme_pubclean()
#------------------------------------------------------------------
#Average Car Price distribution on fueltype by Company
ggplot(data = carprice_assignment,
       aes(x = factor(carprice_assignment$fueltype)), y = mean(carprice_assignment$price)) + #(..count..)
  geom_bar() + facet_wrap(~factor(carprice_assignment$company_name)) +
  labs(title="Average Car Price by Company"
       , subtitle="Company Name"
       , x = "fueltype" 
       , y = "Average Price") 
#------------------------------------------------------------------
#Average Car Price distribution on fueltype by Company
ggplot() + geom_bar(aes(y = mean(price), x = company_name, fill = fueltype)
                    ,data = carprice_assignment, stat="identity")
#------------------------------------------------------------------
#Average Car Price distribution on aspiration by Company
ggplot() + geom_bar(aes(y = mean(price), x = company_name, fill = aspiration)
                    ,data = carprice_assignment, stat="identity")
#-------------------------------------------------------------------
#Average Car Price distribution on doornumber by Company
ggplot() + geom_bar(aes(y = mean(price), x = company_name, fill = doornumber)
                    ,data = carprice_assignment, stat="identity")
#---------------------------------------------------------------------
#Average Car Price distribution on carbody by Company
ggplot() + geom_bar(aes(y = mean(price), x = company_name, fill = carbody)
                    ,data = carprice_assignment, stat="identity")
#---------------------------------------------------------------------
#Average Car Price distribution on drivewheel by Company
ggplot() + geom_bar(aes(y = mean(price), x = company_name, fill = drivewheel)
                    ,data = carprice_assignment, stat="identity")
#---------------------------------------------------------------------
#Average Car Price distribution on enginelocation by Company
ggplot() + geom_bar(aes(y = mean(price), x = company_name, fill = enginelocation)
                    ,data = carprice_assignment, stat="identity")
#---------------------------------------------------------------------
#Average Car Price distribution on enginetype by Company
ggplot() + geom_bar(aes(y = mean(price), x = company_name, fill = enginetype)
                    ,data = carprice_assignment, stat="identity")
#---------------------------------------------------------------------
#Average Car Price distribution on cylindernumber by Company
ggplot() + geom_bar(aes(y = mean(price), x = company_name, fill = cylindernumber)
                    ,data = carprice_assignment, stat="identity")
#---------------------------------------------------------------------
#Average Car Price distribution on enginesize by Company
ggplot() + geom_bar(aes(y = mean(price), x = company_name, fill = enginesize)
                    ,data = carprice_assignment, stat="identity")
#---------------------------------------------------------------------
#Average Car Price distribution on fuelsystem by Company
ggplot() + geom_bar(aes(y = mean(price), x = company_name, fill = fuelsystem)
                    ,data = carprice_assignment, stat="identity")
#---------------------------------------------------------------------
#Average Car Price distribution on cylindernumber by Company
ggplot() + geom_bar(aes(y = mean(price), x = company_name, fill = cylindernumber)
                    ,data = carprice_assignment, stat="identity")
#---------------------------------------------------------------------
library(psych)
col_list <- c("wheelbase","carlength","carwidth","carheight","curbweight","boreratio","stroke" ,"compressionratio","horsepower","peakrpm","citympg","highwaympg","price" )
pairs.panels(carprice_assignment[col_list])
#-----------------------------------------------------------------
#-----------------------------------------------------------------
# Removing Columns
#-----------------------------------------------------------------
carprice_assignment$CarName <- NULL
carprice_assignment$fueltype <- NULL
carprice_assignment$aspiration <- NULL
carprice_assignment$doornumber <- NULL
carprice_assignment$carbody <- NULL
carprice_assignment$drivewheel <- NULL
carprice_assignment$enginelocation <- NULL
carprice_assignment$enginetype <- NULL
carprice_assignment$cylindernumber <- NULL
carprice_assignment$fuelsystem <- NULL
carprice_assignment$car_ID <- NULL
carprice_assignment$symboling <- NULL
carprice_assignment$company_name <- NULL
#------------------------------------------------------------------
#Making Copy of the Dataframe for Analysis.
carprice_assignment_cp <-carprice_assignment
#-------------------------------------------------------------------
#outlier treatments
#-------------------------------------------------------------------
#...............................................................
quantile(carprice_assignment_cp$enginesize,seq(0,1,0.01))
#distribution changes after 96th percentage
carprice_assignment_cp$enginesize[(which(carprice_assignment_cp$enginesize > 209))] <- 209
#...............................................................
quantile(carprice_assignment_cp$horsepower,seq(0,1,0.01))
#distribution changes after 97th %
carprice_assignment_cp$horsepower[(which(carprice_assignment_cp$horsepower > 184.00))] <- 184.00
#...............................................................
quantile(carprice_assignment_cp$compressionratio,seq(0,1,0.01))
#distribution changes after 90th %
carprice_assignment_cp$compressionratio[(which(carprice_assignment_cp$compressionratio > 10.9400))] <- 10.9400

#------------------------------------------------------------------
#******************************************************************
# Building Model
#******************************************************************
# separate training and testing data
column_list <- c("wheelbase","carlength","carwidth","carheight","curbweight","enginesize","boreratio","stroke","compressionratio","horsepower","peakrpm","citympg"                                  
,"highwaympg","price","carprice_assignment_fueltype_diesel","carprice_assignment_fueltype_gas","carprice_assignment_aspiration_std","carprice_assignment_aspiration_turbo"     
,"carprice_assignment_doornumber_four","carprice_assignment_doornumber_two","carprice_assignment_carbody_convertible","carprice_assignment_carbody_hardtop"      
,"carprice_assignment_carbody_hatchback","carprice_assignment_carbody_sedan","carprice_assignment_carbody_wagon","carprice_assignment_drivewheel_4wd"       
,"carprice_assignment_drivewheel_fwd","carprice_assignment_drivewheel_rwd","carprice_assignment_enginelocation_front","carprice_assignment_enginelocation_rear"  
,"carprice_assignment_enginetype_dohc","carprice_assignment_enginetype_dohcv","carprice_assignment_enginetype_l","carprice_assignment_enginetype_ohc"       
,"carprice_assignment_enginetype_ohcf","carprice_assignment_enginetype_ohcv","carprice_assignment_enginetype_rotor","carprice_assignment_cylindernumber_eight" 
,"carprice_assignment_cylindernumber_five","carprice_assignment_cylindernumber_four","carprice_assignment_cylindernumber_six","carprice_assignment_cylindernumber_three" 
,"carprice_assignment_cylindernumber_twelve","carprice_assignment_cylindernumber_two","carprice_assignment_fuelsystem_1bbl","carprice_assignment_fuelsystem_2bbl"      
,"carprice_assignment_fuelsystem_4bbl","carprice_assignment_fuelsystem_idi","carprice_assignment_fuelsystem_mfi","carprice_assignment_fuelsystem_mpfi"      
,"carprice_assignment_fuelsystem_spdi","carprice_assignment_fuelsystem_spfi","carprice_assignment_symboling_-2","carprice_assignment_symboling_-1"         
,"carprice_assignment_symboling_0","carprice_assignment_symboling_1","carprice_assignment_symboling_2","carprice_assignment_symboling_3"          
,"carprice_assignment_ALFA-ROMEO","carprice_assignment_AUDI","carprice_assignment_BMW","carprice_assignment_BUICK","carprice_assignment_CHEVROLET","carprice_assignment_DODGE"                
,"carprice_assignment_HONDA","carprice_assignment_ISUZU","carprice_assignment_JAGUAR","carprice_assignment_MAZDA","carprice_assignment_MERCURY","carprice_assignment_MITSUBISHI"           
,"carprice_assignment_NISSAN","carprice_assignment_PEUGEOT","carprice_assignment_PLYMOUTH","carprice_assignment_PORSCHE","carprice_assignment_RENAULT","carprice_assignment_SAAB"                 
,"carprice_assignment_SUBARU","carprice_assignment_TOYOTA","carprice_assignment_VOLKSWAGEN","carprice_assignment_VOLVO")
#...................................................................................
#creating train and test data
library(MASS)
set.seed(100)
trainindices= sample(1:nrow(carprice_assignment_cp), 0.7*nrow(carprice_assignment_cp))
train = carprice_assignment_cp[trainindices,column_list]
test = carprice_assignment_cp[-trainindices,column_list]

library(car)
# ................................................................................
# Build model 1 containing all variables
# ................................................................................
model_1 <-lm(train$price~.,data=train)
summary(model_1)

#R Square	0.9752
#Adjusted R Square	0.9554

#To summarise we will use stepAIC to eliminate a chunk of insignificant variables 
#then we follow the backward selection approach.
#Eliminating variables in each stage depending on p-value and VIF.
library(MASS)

step1 <- stepAIC(model_1, direction="both")

#----------------------------
# ................................................................................
# The following redundant variables of the linear dependent variables will be eliminated.
#-----
#carprice_assignment_fueltype_gas,carprice_assignment_aspiration_turbo,carprice_assignment_doornumber_two
#carprice_assignment_carbody_wagon,carprice_assignment_drivewheel_rwd,carprice_assignment_enginelocation_rear
#carprice_assignment_enginetype_dohcv,carprice_assignment_enginetype_rotor,carprice_assignment_cylindernumber_twelve
#carprice_assignment_cylindernumber_two,carprice_assignment_fuelsystem_idi,carprice_assignment_fuelsystem_spfi
#carprice_assignment_symboling_3,carprice_assignment_PEUGEOT,carprice_assignment_SUBARU
#carprice_assignment_VOLVO,carprice_assignment_fuelsystem_4bbl,carprice_assignment_fuelsystem_spdi,
#carprice_assignment_CHEVROLET,carprice_assignment_PORSCHE

#-------------------------------------------------------------------------------
#renaming column
colnames(train)[colnames(train)=="carprice_assignment_symboling_-2"] <- "carprice_assignment_symboling_minus2"
colnames(train)[colnames(train)=="carprice_assignment_symboling_-1"] <- "carprice_assignment_symboling_minus1"
colnames(train)[colnames(train)=="carprice_assignment_ALFA-ROMEO"] <- "carprice_assignment_ALFA_ROMEO"
#------
colnames(test)[colnames(test)=="carprice_assignment_symboling_-2"] <- "carprice_assignment_symboling_minus2"
colnames(test)[colnames(test)=="carprice_assignment_symboling_-1"] <- "carprice_assignment_symboling_minus1"
colnames(test)[colnames(test)=="carprice_assignment_ALFA-ROMEO"] <- "carprice_assignment_ALFA_ROMEO"
#-----

#----------------------------------------------------------------------------------
#Model 1.1
model_1.1 <-lm(formula = price~wheelbase+carlength+carwidth+carheight+curbweight+
                 enginesize+boreratio+stroke+compressionratio+horsepower+peakrpm+
                 citympg+highwaympg+carprice_assignment_fueltype_diesel+
                 carprice_assignment_aspiration_std+carprice_assignment_carbody_hatchback+
                 carprice_assignment_carbody_sedan+carprice_assignment_drivewheel_4wd+
                 carprice_assignment_doornumber_four+
                 carprice_assignment_carbody_convertible+
                 carprice_assignment_carbody_hardtop+carprice_assignment_drivewheel_fwd+
                 carprice_assignment_enginelocation_front+carprice_assignment_enginetype_dohc+
                 carprice_assignment_enginetype_l+carprice_assignment_enginetype_ohc+
                 carprice_assignment_enginetype_ohcf+carprice_assignment_enginetype_ohcv+
                 carprice_assignment_cylindernumber_eight+carprice_assignment_cylindernumber_five+
                 carprice_assignment_cylindernumber_four+carprice_assignment_cylindernumber_six+
                 carprice_assignment_cylindernumber_three+carprice_assignment_fuelsystem_1bbl+
                 carprice_assignment_fuelsystem_2bbl+
                 carprice_assignment_fuelsystem_mfi+carprice_assignment_fuelsystem_mpfi+
                 carprice_assignment_symboling_minus2+
                 carprice_assignment_symboling_minus1+carprice_assignment_symboling_0+
                 carprice_assignment_symboling_1+carprice_assignment_symboling_2+
                 carprice_assignment_ALFA_ROMEO+carprice_assignment_AUDI+carprice_assignment_BMW+
                 carprice_assignment_BUICK+carprice_assignment_DODGE+
                 carprice_assignment_HONDA+carprice_assignment_ISUZU+carprice_assignment_JAGUAR+
                 carprice_assignment_MAZDA+carprice_assignment_MERCURY+carprice_assignment_MITSUBISHI+
                 carprice_assignment_NISSAN+carprice_assignment_PLYMOUTH+
                 carprice_assignment_RENAULT+carprice_assignment_SAAB+carprice_assignment_TOYOTA+
                 carprice_assignment_VOLKSWAGEN
               , data = train)

summary(model_1.1)

step1.1 <- stepAIC(model_1.1, direction="both")

vif(model_1.1)
# ................................................................................
#Model 2
# ................................................................................
# Eliminating the following as its VIF > 10 and R-squared > 0.05
#wheelbase,carlength,curbweight,enginesize,boreratio,stroke,compressionratio,
#citympg,highwaympg,carprice_assignment_fueltype_diesel,carprice_assignment_carbody_hatchback,
#carprice_assignment_drivewheel_fwd,carprice_assignment_enginetype_dohc,carprice_assignment_enginetype_l,
#carprice_assignment_enginetype_ohc,carprice_assignment_enginetype_ohcf,carprice_assignment_enginetype_ohcv,
#carprice_assignment_cylindernumber_eight,carprice_assignment_cylindernumber_five,
#carprice_assignment_cylindernumber_four,carprice_assignment_cylindernumber_six,
#carprice_assignment_cylindernumber_three,carprice_assignment_fuelsystem_1bbl,
#carprice_assignment_fuelsystem_2bbl,carprice_assignment_fuelsystem_4bbl,
#carprice_assignment_fuelsystem_mpfi,carprice_assignment_fuelsystem_spdi,
#carprice_assignment_symboling_0,carprice_assignment_AUDI,carprice_assignment_DODGE,
#carprice_assignment_HONDA,carprice_assignment_JAGUAR,carprice_assignment_MAZDA,
#carprice_assignment_MITSUBISHI,carprice_assignment_NISSAN,carprice_assignment_TOYOTA,
#carprice_assignment_VOLKSWAGEN

model_2 <-lm(formula = price~carwidth+carheight+horsepower+peakrpm+
                 carprice_assignment_aspiration_std+carprice_assignment_doornumber_four+
                 carprice_assignment_carbody_convertible+carprice_assignment_carbody_hardtop+
                 carprice_assignment_carbody_sedan+carprice_assignment_drivewheel_4wd+
                 carprice_assignment_enginelocation_front+carprice_assignment_fuelsystem_mfi+
                 carprice_assignment_symboling_minus2+carprice_assignment_symboling_minus1+
                 carprice_assignment_symboling_1+carprice_assignment_symboling_2+
               carprice_assignment_ALFA_ROMEO+carprice_assignment_BMW+carprice_assignment_BUICK+
                 carprice_assignment_CHEVROLET+carprice_assignment_DODGE+carprice_assignment_ISUZU+
                 carprice_assignment_MERCURY+carprice_assignment_PLYMOUTH+carprice_assignment_PORSCHE+
                 carprice_assignment_RENAULT+carprice_assignment_SAAB, data = train)

summary(model_2)

#R Square	0.9339
#Adjusted R Square	0.9184

library(MASS)

step2 <- stepAIC(model_2, direction="both")

vif(model_2)
# ................................................................................
#Model 3
# ................................................................................
#Removing carprice_assignment_enginelocation_front as it has higher VIF of 5.719495

model_3 <-lm(formula = price~carwidth+carheight+horsepower+peakrpm+
               carprice_assignment_aspiration_std+carprice_assignment_doornumber_four+
               carprice_assignment_carbody_convertible+carprice_assignment_carbody_hardtop+
               carprice_assignment_carbody_sedan+carprice_assignment_drivewheel_4wd+
               carprice_assignment_fuelsystem_mfi+
               carprice_assignment_symboling_minus2+carprice_assignment_symboling_minus1+
               carprice_assignment_symboling_1+carprice_assignment_symboling_2+
               carprice_assignment_ALFA_ROMEO+carprice_assignment_BMW+carprice_assignment_BUICK+
               carprice_assignment_CHEVROLET+carprice_assignment_DODGE+carprice_assignment_ISUZU+
               carprice_assignment_MERCURY+carprice_assignment_PLYMOUTH+carprice_assignment_PORSCHE+
               carprice_assignment_RENAULT+carprice_assignment_SAAB, data = train)

summary(model_3)

step3 <- stepAIC(model_3, direction="both")

vif(model_3)

#Model	3
#R Square	: 0.9254
#Adjusted R Square :0.9087

# ................................................................................
#Model 4
# ................................................................................
#based on high VIF and Pvalue we will be eliminating the following
#carheight,carprice_assignment_doornumber_four

model_4 <-lm(formula = price~carwidth+horsepower+peakrpm+
               carprice_assignment_aspiration_std+
               carprice_assignment_carbody_convertible+carprice_assignment_carbody_hardtop+
               carprice_assignment_carbody_sedan+carprice_assignment_drivewheel_4wd+
               carprice_assignment_fuelsystem_mfi+
               carprice_assignment_symboling_minus2+carprice_assignment_symboling_minus1+
               carprice_assignment_symboling_1+carprice_assignment_symboling_2+
               carprice_assignment_ALFA_ROMEO+carprice_assignment_BMW+carprice_assignment_BUICK+
               carprice_assignment_CHEVROLET+carprice_assignment_DODGE+carprice_assignment_ISUZU+
               carprice_assignment_MERCURY+carprice_assignment_PLYMOUTH+carprice_assignment_PORSCHE+
               carprice_assignment_RENAULT+carprice_assignment_SAAB, data = train)

summary(model_4)

step4 <- stepAIC(model_4, direction="both")

vif(model_4)

#Model	4
#R Square	0.9231
#Adjusted R Square	0.9075

# ................................................................................
#Model 5
# ................................................................................
#based on high VIF and Pvalue we will be eliminating the following
#carprice_assignment_DODGE,
#carprice_assignment_ISUZU,carprice_assignment_PLYMOUTH

model_5 <-lm(formula = price~carwidth+horsepower+peakrpm+
               carprice_assignment_aspiration_std+
               carprice_assignment_carbody_convertible+carprice_assignment_carbody_hardtop+
               carprice_assignment_carbody_sedan+carprice_assignment_drivewheel_4wd+
               carprice_assignment_fuelsystem_mfi+
               carprice_assignment_symboling_minus2+carprice_assignment_symboling_minus1+
               carprice_assignment_symboling_1+carprice_assignment_symboling_2+
               carprice_assignment_ALFA_ROMEO+carprice_assignment_BMW+carprice_assignment_BUICK+
               carprice_assignment_CHEVROLET+
               carprice_assignment_MERCURY+carprice_assignment_PORSCHE+
               carprice_assignment_RENAULT+carprice_assignment_SAAB, data = train)

summary(model_5)

step5 <- stepAIC(model_5, direction="both")

vif(model_5)

#Model	5
#R Square	: 0.9231
#Adjusted R Square :	0.9097


# ................................................................................
#Model 6
# ................................................................................
#based on high Pvalue and VIF we will be eliminating the following
#carprice_assignment_symboling_minus2,carprice_assignment_ALFA_ROMEO,
#carprice_assignment_RENAULT,carprice_assignment_SAAB


model_6 <-lm(formula = price~carwidth+horsepower+peakrpm+
               carprice_assignment_aspiration_std+
               carprice_assignment_carbody_convertible+carprice_assignment_carbody_hardtop+
               carprice_assignment_carbody_sedan+carprice_assignment_drivewheel_4wd+
               carprice_assignment_fuelsystem_mfi+
               carprice_assignment_symboling_minus1+
               carprice_assignment_symboling_1+carprice_assignment_symboling_2+
               carprice_assignment_BMW+carprice_assignment_BUICK+
               carprice_assignment_CHEVROLET+
               carprice_assignment_MERCURY+carprice_assignment_PORSCHE
             , data = train)

summary(model_6)

step6 <- stepAIC(model_6, direction="both")

vif(model_6)

#Model	6
#R Square	: 0.9218
#Adjusted R Square :	0.9112


# ................................................................................
#Model 7
# ................................................................................
#based on high Pvalue and VIF we will be eliminating the following
#carprice_assignment_symboling_minus1,carprice_assignment_symboling_1


model_7 <-lm(formula = price~carwidth+horsepower+peakrpm+
               carprice_assignment_aspiration_std+
               carprice_assignment_carbody_convertible+carprice_assignment_carbody_hardtop+
               carprice_assignment_carbody_sedan+carprice_assignment_drivewheel_4wd+
               carprice_assignment_fuelsystem_mfi+carprice_assignment_symboling_2+
               carprice_assignment_BMW+carprice_assignment_BUICK+
               carprice_assignment_CHEVROLET+
               carprice_assignment_MERCURY+carprice_assignment_PORSCHE
             , data = train)

summary(model_7)

step7 <- stepAIC(model_7, direction="both")

vif(model_7)

#Model	7
#R Square	: 0.9209
#Adjusted R Square	: 0.9115


# ................................................................................
#Model 8
# ................................................................................
#based on high Pvalue and VIF we will be eliminating the following
#carprice_assignment_fuelsystem_mfi


model_8 <-lm(formula = price~carwidth+horsepower+peakrpm+
               carprice_assignment_aspiration_std+
               carprice_assignment_carbody_convertible+carprice_assignment_carbody_hardtop+
               carprice_assignment_carbody_sedan+carprice_assignment_drivewheel_4wd+
               carprice_assignment_symboling_2+
               carprice_assignment_BMW+carprice_assignment_BUICK+
               carprice_assignment_CHEVROLET+
               carprice_assignment_MERCURY+carprice_assignment_PORSCHE
             , data = train)

summary(model_8)

step8 <- stepAIC(model_8, direction="both")

vif(model_8)

#Model	8
#R Square	: 0.9203
#Adjusted R Square :	0.9116


# ................................................................................
#Model 9
# ................................................................................
#based on high Pvalue and VIF we will be eliminating the following
#carprice_assignment_symboling_2


model_9 <-lm(formula = price~carwidth+horsepower+peakrpm+
               carprice_assignment_aspiration_std+
               carprice_assignment_carbody_convertible+carprice_assignment_carbody_hardtop+
               carprice_assignment_carbody_sedan+carprice_assignment_drivewheel_4wd+
               carprice_assignment_BMW+carprice_assignment_BUICK+
               carprice_assignment_CHEVROLET+
               carprice_assignment_MERCURY+carprice_assignment_PORSCHE
             , data = train)

summary(model_9)

step9 <- stepAIC(model_9, direction="both")

vif(model_9)

#Model	9
#R Square	: 0.9192
#Adjusted R Square :	0.911


# ................................................................................
#Model 10
# ................................................................................
#based on high Pvalue and VIF we will be eliminating the following
#carprice_assignment_carbody_hardtop


model_10 <-lm(formula = price~carwidth+horsepower+peakrpm+
               carprice_assignment_aspiration_std+
               carprice_assignment_carbody_convertible+
               carprice_assignment_carbody_sedan+carprice_assignment_drivewheel_4wd+
               carprice_assignment_BMW+carprice_assignment_BUICK+
               carprice_assignment_CHEVROLET+
               carprice_assignment_MERCURY+carprice_assignment_PORSCHE
             , data = train)

summary(model_10)

step10 <- stepAIC(model_10, direction="both")

vif(model_10)

#Model	10
#R Square :	0.9187
#Adjusted R Square :	0.9111


# ................................................................................
#Model 11
# ................................................................................
#based on high Pvalue and VIF we will be eliminating the following
#carprice_assignment_drivewheel_4wd

model_11 <-lm(formula = price~carwidth+horsepower+peakrpm+
                carprice_assignment_aspiration_std+
                carprice_assignment_carbody_convertible+
                carprice_assignment_carbody_sedan+
                carprice_assignment_BMW+carprice_assignment_BUICK+
                carprice_assignment_CHEVROLET+
                carprice_assignment_MERCURY+carprice_assignment_PORSCHE
              , data = train)

summary(model_11)

step11 <- stepAIC(model_11, direction="both")

vif(model_11)

#Model	11
#R Square	: 0.9174
#Adjusted R Square :	0.9104


# ................................................................................
#Model 12
# ................................................................................
#based on high Pvalue and VIF we will be eliminating the following
#carprice_assignment_MERCURY


model_12 <-lm(formula = price~carwidth+horsepower+peakrpm+
                carprice_assignment_aspiration_std+
                carprice_assignment_carbody_convertible+
                carprice_assignment_carbody_sedan+
                carprice_assignment_BMW+carprice_assignment_BUICK+
                carprice_assignment_CHEVROLET+
                carprice_assignment_PORSCHE
              , data = train)

summary(model_12)

step12 <- stepAIC(model_12, direction="both")

vif(model_12)

#Model	12
#R Square	: 0.9159
#Adjusted R Square :	0.9096


# ................................................................................
#Model 13
# ................................................................................
#based on high Pvalue and VIF we will be eliminating the following
#peakrpm

model_13 <-lm(formula = price~carwidth+horsepower+
                carprice_assignment_aspiration_std+
                carprice_assignment_carbody_convertible+
                carprice_assignment_carbody_sedan+
                carprice_assignment_BMW+carprice_assignment_BUICK+
                carprice_assignment_CHEVROLET+
                carprice_assignment_PORSCHE
              , data = train)

summary(model_13)

step13 <- stepAIC(model_13, direction="both")

vif(model_13)

#Model	13
#R Square	: 0.9144
#Adjusted R Square :	0.9086


# ................................................................................
#Model 14
# ................................................................................
#based on high Pvalue and VIF we will be eliminating the following
#carprice_assignment_aspiration_std

model_14 <-lm(formula = price~carwidth+horsepower+
                carprice_assignment_carbody_convertible+
                carprice_assignment_carbody_sedan+
                carprice_assignment_BMW+carprice_assignment_BUICK+
                carprice_assignment_CHEVROLET+
                carprice_assignment_PORSCHE
              , data = train)

summary(model_14)

step14 <- stepAIC(model_14, direction="both")

vif(model_14)

#Model	14
#R Square	: 0.9125
#Adjusted R Square :	0.9073


# ................................................................................
#Model 15
# ................................................................................
#based on high Pvalue and VIF we will be eliminating the following variable
#carprice_assignment_CHEVROLET

model_15 <-lm(formula = price~carwidth+horsepower+
                carprice_assignment_carbody_convertible+
                carprice_assignment_carbody_sedan+
                carprice_assignment_BMW+carprice_assignment_BUICK+
                carprice_assignment_PORSCHE
              , data = train)

summary(model_15)

step15 <- stepAIC(model_15, direction="both")

vif(model_15)

#Model	15
#R Square	: 0.9097
#Adjusted R Square :0.905


# ................................................................................
#Model 16
# ................................................................................
#based on high Pvalue and VIF we will be eliminating the following variable
#carprice_assignment_carbody_sedan

model_16 <-lm(formula = price~carwidth+horsepower+
                carprice_assignment_carbody_convertible+
                carprice_assignment_BMW+carprice_assignment_BUICK+
                carprice_assignment_PORSCHE
              , data = train)

summary(model_16)

step16 <- stepAIC(model_16, direction="both")

vif(model_16)

#Model	16
#R Square	: 0.9046
#Adjusted R Square :	0.9004


# ................................................................................
#Model 17
# ................................................................................
#based on high Pvalue and VIF we will be eliminating the following
#carprice_assignment_carbody_convertible

model_17 <-lm(formula = price~carwidth+horsepower+
                carprice_assignment_BMW+carprice_assignment_BUICK+
                carprice_assignment_PORSCHE
              , data = train)

summary(model_17)

step17 <- stepAIC(model_17, direction="both")

vif(model_17)

#Coefficients:
#  Estimate Std. Error t value Pr(>|t|)    
#(Intercept)                 -71539.696   9901.014  -7.225 3.16e-11 ***
#  carwidth                      1127.023    159.278   7.076 6.99e-11 ***
#  horsepower                      90.499      9.001  10.054  < 2e-16 ***
#  carprice_assignment_BMW       8999.815   1574.128   5.717 6.49e-08 ***
#  carprice_assignment_BUICK    12001.217   1234.229   9.724  < 2e-16 ***
#  carprice_assignment_PORSCHE  13320.720   1506.585   8.842 4.13e-15 ***
#  ---
#  Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1

#Residual standard error: 2658 on 137 degrees of freedom
#Multiple R-squared:  0.8979,	Adjusted R-squared:  0.8942 
#F-statistic: 240.9 on 5 and 137 DF,  p-value: < 2.2e-16

#...................................................................
#Which variables are significant in predicting the price of a car?
#carwidth, horsepower, carprice_assignment_BMW, carprice_assignment_BUICK, carprice_assignment_PORSCHE

#R-squared:  0.8979 (89%)
#Adjusted R-squared:  0.8942 (89%)
#---------------------------------------------------------------

# predicting the results in test dataset
Predict_1 <- predict(model_17,test[,-1])
test$test_price <- Predict_1

# testing the r square between actual and predicted price 
r <- cor(test$price,test$test_price)
rsquared <- cor(test$price,test$test_price)^2
rsquared

#Predicted R^2 : 0.807603

#calculate error by Actual-Predicted Price
test$error_pred<- test$price - test$test_price

#Density of the Actual Price
actual_price_density_plot <- ggplot(test) +
  geom_density(aes(x = price)) +
  geom_rug(aes(x = price, y = 0), position = position_jitter(height = 0)) +
  labs(title="Density of the Actual Price") 

#Density of the Predicted Price
predicted_price_density_plot <- ggplot(test) +
  geom_density(aes(x = test_price)) +
  geom_rug(aes(x = test_price, y = 0), position = position_jitter(height = 0)) +
  labs(title="Density of the Predicted Price") 

#Error Density graph
error_density_plot <- ggplot(test) +
  geom_density(aes(x = error_pred)) +
  geom_rug(aes(x = error_pred, y = 0), position = position_jitter(height = 0)) +
  labs(title="Error Density graph") 

#How well those variables describe the price of a car?
grid.arrange(
  actual_price_density_plot,
  predicted_price_density_plot,
  error_density_plot,
  nrow = 1,
  top = "Actual vs Predicted and Error Density"
  )

#------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------




