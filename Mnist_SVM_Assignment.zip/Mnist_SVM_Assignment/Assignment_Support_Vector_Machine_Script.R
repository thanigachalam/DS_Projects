#-----------------------------------------------------------------------------------
# Assignment - Support Vector Machine
#-----------------------------------------------------------------------------------
# steps performed in this section
# 1. Business Understanding
# 2. Data Understanding
# 3. Data Preparation
# 4. Model Building 
#     Linear kernel
#     RBF Kernel
# 5. Conclusion

#-----------------------------------------------------------------------------------
#1.
# Problem Statement
#-------------------
#A classic problem in the field of pattern recognition is that of handwritten 
#digit recognition. Suppose that you have an image of a digit submitted by a 
#user via a scanner, a tablet, or other digital devices. The goal is to develop 
#a model that can correctly identify the digit (between 0-9) written in an image. 

#Objective
#-------------------
#required to develop a model using Support Vector Machine which should correctly 
#classify the handwritten digits based on the pixel values given as features.


#-----------------------------------------------------------------------------------
#Required R Packages
#-----------------------------------------------------------------------------------

required_packages <- c("caret","kernlab","dplyr","readr","ggplot2","gridExtra","doParallel")
new_packages <- required_packages[!(required_packages %in% installed.packages()[,"Package"])]
if (length(new_packages)) install.packages(new_packages)

library(caret)
library(kernlab)
library(dplyr)
library(readr)
library(ggplot2)
library(gridExtra)
library(readr)
library(dplyr)

# 2. Data Understanding
#-------------------------------------------------------------------
# Importing source data and merging train and test data for analysis.
#-------------------------------------------------------------------
mnist_train_raw <- read.csv("mnist_train.csv", header = F)
mnist_test_raw <- read.csv("mnist_test.csv", header = F)

mnist_complete_dataset <- rbind(mnist_train_raw,mnist_test_raw)

#-------------------------------------------------------------------
#dim check

dim(mnist_complete_dataset)

#[1] 70000   785

#--------------------------------------------------------------------
#validating the few data
mnist_train_small_dataset <- head(mnist_complete_dataset)
#--------------------------------------------------------------------

#--------------------------------------------------------------------
#checking missing values
missing_data_count <- sapply(mnist_complete_dataset, function(x) sum(is.na(x)))

missing_data_count <- as.data.frame(missing_data_count)
summary(missing_data_count)
#There is no missing values in the dataset.
#--------------------------------------------------------------------
#--------------------------------------------------------------------
#--------------------------- EDA ------------------------------------
#--------------------------------------------------------------------

library(tidyr)

#--------------------------------------------------------------------
#gathering the pixel data from the data set for the first 10000 records
pixels_gathered_dataset <- mnist_complete_dataset %>%
  head(10000) %>%
  rename(label = V1) %>%
  mutate(instance = row_number()) %>%
  gather(pixel, value, -label, -instance) %>%
  tidyr::extract(pixel, "pixel", "(\\d+)", convert = TRUE) %>%
  mutate(pixel = pixel - 2,
         x = pixel %% 28,
         y = 28 - pixel %/% 28)

head(pixels_gathered_dataset)

#--------------------------------------------------------------------
theme_set(theme_light())

#we now take the pixel gathered records each pixel in each image. 
#This will help us the visualize the data. 
#For example, we can visualize the first 12 instances.
pixels_gathered_dataset %>%
  filter(instance <= 12) %>%
  ggplot(aes(x, y, fill = value)) +
  geom_tile() +
  facet_wrap(~ instance + label)

#In dataframe 0 represents blank space (like the edges of the image), 
#and a maximum around 250 represents the darkest points of the image.

#--------------------------------------------------------------------
#Exploring pixel data
ggplot(pixels_gathered_dataset, aes(value)) +
  geom_histogram()

# This trend shows that which pixels have more on the dataset.
# in this we can see more white spaces where it represents 0.

#--------------------------------------------------------------------
# Analyzing the data by pixel summary
pixel_summary_dataset <- pixels_gathered_dataset %>%
  group_by(x, y, label) %>%
  summarize(mean_value = mean(value)) %>%
  ungroup()

pixel_summary_dataset

#--------------------------------------------------------------------
#working with black-and-white photographs, we might find lot more variety

#We visualize the images by average digits of ten separate facets.
#to see how the hand written data looks for the each number.

pixel_summary_dataset %>%
  ggplot(aes(x, y, fill = mean_value)) +
  geom_tile() +
  scale_fill_gradient2(low = "white", high = "black", mid = "gray", midpoint = 127.5) +
  facet_wrap(~ label, nrow = 2) +
  labs(title = "Average value of each pixel in digits",
       fill = "Average value") +
  theme_void()

#--------------------------------------------------------------------
#We are treating each image as a 784-dimensional point (28 by 28)

#In this some of the digits will fall widely outside the norm. 
#It's useful to explore atypical cases

#We will take the Euclidean distance (square root of the sum of squares) of each 
#image to its label's centroid.

pixels_joined_dataset <- pixels_gathered_dataset %>%
  inner_join(pixel_summary_dataset, by = c("label", "x", "y"))

image_distances_dataset <- pixels_joined_dataset %>%
  group_by(label, instance) %>%
  summarize(euclidean_distance = sqrt(mean((value - mean_value) ^ 2)))

image_distances_dataset

# show the Euclidean distance to the digit centroid
ggplot(image_distances_dataset, aes(factor(label), euclidean_distance)) +
  geom_boxplot() +
  labs(x = "Digit",
       y = "Euclidean distance to the digit centroid")

# 1. In this we can see 1 is having especially low distances to the centroid
# 2. We can see most variability are 0 and 2
# 3. In this we can see that every digit has at large distance from centroid
#     and few cases unusaly large.

#--------------------------------------------------------------------
#least resemblance to their central digit

worst_instances_dataset <- image_distances_dataset %>%
  top_n(6, euclidean_distance) %>%
  mutate(number = rank(-euclidean_distance))

pixels_gathered_dataset %>%
  inner_join(worst_instances_dataset, by = c("label", "instance")) %>%
  ggplot(aes(x, y, fill = value)) +
  geom_tile(show.legend = FALSE) +
  scale_fill_gradient2(low = "white", high = "black", mid = "gray", midpoint = 127.5) +
  facet_grid(label ~ number) +
  labs(title = "Least typical digits",
       subtitle = "The 6 digits within each label that had the greatest distance to the centroid") +
  theme_void() +
  theme(strip.text = element_blank())

#This is output gives us the ability to vizualize the what kind of problem are there
#with the digits.

# 3. Data Preparation
#---------------------------------------------------------------------------------
# train and test data preparation for Model testing
#---------------------------------------------------------------------------------
#naming the first column, which is label data
colnames(mnist_complete_dataset)[1] <- c('label')
mnist_complete_dataset$label <- as.factor(mnist_complete_dataset$label)

#Considering only 15% of data for this model building.
set.seed(100)

#Create a random sample of integers sample from 1 to nrow(iris)
samp <- sample(1:nrow(mnist_complete_dataset), size=round(0.15*nrow(mnist_complete_dataset)), replace=FALSE)

mnist_15_percentage_dataset <- mnist_complete_dataset[samp,]  #Only takes 15 percent data for analysis.

dataset_index <- sample(1:nrow(mnist_15_percentage_dataset), size=round(.7*nrow(mnist_15_percentage_dataset)), replace=FALSE)

train <- mnist_15_percentage_dataset[dataset_index,]  #70 percent data from 15% of the data.
test <- mnist_15_percentage_dataset[-dataset_index,] #30 percent data from 15% of the data.

normalize <- function(x) { 
  z=x
  if(min(x)<max(x)){ 
    z=(x - min(x)) / (max(x) - min(x))
  }
  return(z)
}  
  
train1 <- as.data.frame(lapply(train[2:785], normalize)) #MNIST is orignal dataset and MNIST_n is normalised
train1 <- cbind(train$label,train1)
colnames(train1)[1] <- c('label')

test1 <- as.data.frame(lapply(test[2:785], normalize)) #MNIST is orignal dataset and MNIST_n is normalised
test1 <- cbind(test$label,test1)
colnames(test1)[1] <- c('label')

train <- train1
test <- test1

rm(train1)
rm(test1)
#-----------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
# Model Building
#-----------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
# Linear model - SVM  at Cost(C) = 1 : Simple linear svm model
#-----------------------------------------------------------------------------------
library("kernlab")
# Model with C =1
model_1<- ksvm(label ~ ., data = train,scale = FALSE, C=1)

# Predicting the model results 
evaluate_1<- predict(model_1, test)

# Confusion Matrix - Finding accuracy, Sensitivity and specificity
confusionMatrix(evaluate_1, test$label)

#Accuracy : 0.9511

#sum(0.97039+0.9806+0.96429+0.93038+0.96825+0.93774+0.97214+0.95152+0.91496+0.91554)/10
#Avg Sensitivity : 0.950581

#sum(0.99789+0.9943+0.99472+0.99224+0.99224+0.99205+0.99752+0.99610+0.99502+0.99369)/10
#Avg Specificity: 0.994577
#--------------------------------------------------------------------
# Linear model - SVM  at Cost(C) = 10
#####################################################################

# Model with C =10.
model_10<- ksvm(label ~ ., data = train,scale = FALSE,C=10)

# Predicting the model results
evaluate_10<- predict(model_10, test)

# Confusion Matrix - finding accuracy, sensitivity and specificity
confusionMatrix(evaluate_10, test$label)

#Accuracy : 0.9629
#sum(0.97039+0.9806+0.98701+0.96203+0.96190+0.95720+0.9752+0.94848+0.9238+0.96284)/10
#Avg Sensitivity : 0.962945

#sum(0.99684+0.9971+0.99507+0.99577+0.99541+0.99482+0.9972+0.99752+0.9954+0.99369)/10
#Avg Specificity : 0.995882

#--------------------------------------------------------------------
# Hyperparameter tuning and Cross Validation  - Linear - SVM 
######################################################################

# We will use the train function from caret package to perform crossvalidation

trainControl <- trainControl(method="cv", number=5)
# Number - Number of folds 
# Method - cross validation

metric <- "Accuracy"

set.seed(100)

# making a grid of C values. 
grid <- expand.grid(C=seq(.01, 2.5, by=.25))

# Performing 5-fold cross validation
fit.svm <- train(label~., data=train, method="svmLinear", metric=metric, 
                 tuneGrid=grid, 
                 trControl=trainControl)


# Printing cross validation result
print(fit.svm)

#C     Accuracy   Kappa    
#0.01  0.9172728  0.9080214
#0.26  0.9088370  0.8986381
#0.51  0.9051646  0.8945539
#0.76  0.9027126  0.8918273
#1.01  0.9014892  0.8904671
#1.26  0.9021692  0.8912231
#1.51  0.9020334  0.8910722
#1.76  0.9021698  0.8912238
#2.01  0.9020339  0.8910727
#2.26  0.9018979  0.8909213

#Accuracy was used to select the optimal model using the largest value.
#The final value used for the model was C = 0.01.

plot(fit.svm)

###############################################################################
# Valdiating the model after cross validation on test data
###############################################################################

evaluate_linear_test<- predict(fit.svm, test)
confusionMatrix(evaluate_linear_test, test$label)

#Accuracy : 0.9206

#sum(0.97039+0.9694+0.92208+0.88291+0.93968+0.89494+0.95975+0.92121+0.8563+0.88176)/10
# Avg Sensitivity : 0.919842

#sum(0.99473+0.9910+0.99156+0.98765+0.98871+0.98894+0.99469+0.99433+0.9915+0.98879)/10
# Avg Specificity : 0.99119
##################################################################################
##################################################################################

#---------------------------------------------------------------------------------
#---------------------------------------------------------------------------------
# Non-Linear Model - Kernels
#---------------------------------------------------------------------------------
#---------------------------------------------------------------------------------
#install.packages("doParallel")
library(doParallel)
cl <- makePSOCKcluster(2)
registerDoParallel(cl)


# RBF kernel 
model_rbf <- ksvm(label ~ ., data =train,scale=FALSE, kernel = "rbfdot")

stopCluster(cl)
# Predicting the model results 
Eval_RBF<- predict(model_rbf, test)

#confusion matrix - RBF Kernel
confusionMatrix(Eval_RBF,test$label)

#Accuracy : 0.9511
#sum(0.97039+0.9806+0.96429+0.93038+0.96825+0.93774+0.97214+0.95152+0.91496+0.91554)/10
# Avg Sensitivity : 0.950581

#sum(0.99789+0.9943+0.99472+0.99224+0.99224+0.99205+0.99752+0.99610+0.99502+0.99369)/10
#Avg Specificity : 0.994577

#####################################################################
#Hyperparameter tuning and Cross Validation - Non-Linear - SVM 
######################################################################

# We will use the train function from caret package to perform crossvalidation

# Making grid of "sigma" and C values. 
grid <- expand.grid(.sigma=seq(0.01, 0.05, by=0.01), .C=seq(1, 5, by=1))

cl <- makePSOCKcluster(2)
registerDoParallel(cl)

# Performing 5-fold cross validation
fit.svm_radial <- train(label~., data=train, method="svmRadial", metric=metric, 
                        tuneGrid=grid, trControl=trainControl)
stopCluster(cl)

# Printing cross validation result
print(fit.svm_radial)
# Best tune at sigma = 0.03 and C = 2, Accuracy :  0.9549642

#sigma  C  Accuracy   Kappa    
#0.01   1  0.9420382  0.9355602
#0.01   2  0.9459834  0.9399441
#0.01   3  0.9491132  0.9434230
#0.01   4  0.9495214  0.9438773
#0.01   5  0.9492491  0.9435742
#0.02   1  0.9504736  0.9449373
#0.02   2  0.9534670  0.9482643
#0.02   3  0.9540112  0.9488698
#0.02   4  0.9540113  0.9488699
#0.02   5  0.9538751  0.9487184
#0.03   1  0.9526506  0.9473583
#0.03   2  0.9549642  0.9499300
#0.03   3  0.9544198  0.9493242
#0.03   4  0.9544196  0.9493240
#0.03   5  0.9544196  0.9493240
#0.04   1  0.9530595  0.9478136
#0.04   2  0.9537401  0.9485693
#0.04   3  0.9536040  0.9484179
#0.04   4  0.9537400  0.9485691
#0.04   5  0.9537400  0.9485691
#0.05   1  0.9497940  0.9441818
#0.05   2  0.9507466  0.9452404
#0.05   3  0.9507466  0.9452404
#0.05   4  0.9507466  0.9452404
#0.05   5  0.9507466  0.9452404

#Accuracy was used to select the optimal model using the largest value.
#The final values used for the model were sigma = 0.03 and C = 2.

# Plotting model results
plot(fit.svm_radial)

######################################################################
# Checking overfitting - Non-Linear - SVM
######################################################################

# Validating the model results on test data
evaluate_non_linear<- predict(fit.svm_radial, test)
confusionMatrix(evaluate_non_linear, test$label)

# Accuracy    - 0.9714
# Sensitivity - 0.971692
# Specificity - 0.996821

#Sensitivity : sum(0.98684+0.9806+0.99351+0.96203+0.97143+0.97665+0.9814+0.95152+0.9501+0.96284)/10
#Specificity : sum(0.99824+0.9982+0.99613+0.99577+0.99541+0.99689+0.9982+0.99858+0.9957+0.99509)/10

######################################################################


#-----------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
# 5. Conclusion
#-----------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
#  For this analysis and model building we have considered 15% of data
#from mnist dataset and in this we have merged the test and train dataset and
#considered only 15% data from this.

#The goal was to use simple feature set as input for support vector machine
#that was used for classification. 

#Optimal SVM models were determined by recent Linear kernel 
#and RBF Kernel model and  adjusted C and sigma values
#and used parameter tuning of the support vector
#machine. We tested our proposed method on considered 15%
#MNIST dataset and achieved accuracy of 97.14%. We compared our 
#method with other methods

#our proposed method obtained better accuracy with
#RBF Kernel. This establishes this approach
#as very robust and by using more complex features
#the results could be further improved.

##################################################################################
#Linear model - SVM  at Cost(C) = 1
##################################################################################
#Accuracy : 0.9511
#Avg Sensitivity : 0.950581
#Avg Specificity: 0.994577


##################################################################################
#Linear model - SVM  at Cost(C) = 10
##################################################################################
#Accuracy : 0.9629
#Avg Sensitivity : 0.962945
#Avg Specificity : 0.995882

#***********************************
#cross validation result
#***********************************
#C : 0.01 
#Accuracy : 0.9172728

#*********************************************************
# Valdiating the model after cross validation on test data
#*********************************************************
#Accuracy : 0.9206
# Avg Sensitivity : 0.919842
# Avg Specificity : 0.99119

##################################################################################
# Non-Linear Model - Kernels
##################################################################################
# RBF kernel 

#Accuracy : 0.9511
#Avg Sensitivity : 0.950581
#Avg Specificity : 0.994577

#*********************************************************
#Hyperparameter tuning and Cross Validation - Non-Linear - SVM 
#*********************************************************

# Best tune at sigma = 0.03 and C = 2, Accuracy :  0.9549642

#*********************************************************
# Checking overfitting - Non-Linear - SVM
#*********************************************************
# Accuracy    - 0.9714
# Sensitivity - 0.971692
# Specificity - 0.996821


#---------------------------------------------------------------------------------
#---------------------------------------------------------------------------------
#---------------------------------------------------------------------------------


