#-------------------------------------------------------------------------------------
##---------------------------Acquisition Analysis Assignemnt------------------------##
#-------------------------------------------------------------------------------------
# The following process used to do Acquisition Analysis.
# 1. Business Understanding
# 2. Data Understanding  
# 3. Data Preparation
# 4. Modelling
# 5. Model Evaluation
# 6. Model Deployment and Recommendations

#-------------------------------------------------------
## Business Understanding:- Prospect Profiling
#-------------------------------------------------------

#lodaing dataset
#dataset source: https://archive.ics.uci.edu/ml/datasets/bank+marketing
#bank-full.csv with all examples and 17 inputs, ordered by date (older version of this dataset with less inputs). 
bank_data<- read.csv("bank_marketing.csv", header = TRUE)
bank_data_raw <- bank_data

#NA validation
sum(is.na(bank_data))

#-----------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
# EDA
#-----------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
#1.Identify the relevant predictor variables for response using EDA

library(ggplot2)

# Plotting Age histogram
hist(bank_data$age, col = "light blue", freq = FALSE)

# outlier Treatment for age variable
quantile(bank_data$age,seq(0,1,0.01))

# Box plot 
boxplot(bank_data$age)

# Capping the upper values of age with 71 for above 99% quantile
bank_data[(which(bank_data$age>71)),]$age <- 71

#---------
# Binning the age variable and store it into "binning.age".
bank_data$binning.age <- as.factor(cut(bank_data$age, breaks = c(16, 20, 30, 40, 50, 60, 70, 80)))

# Change the response value to numbers i.e"yes-no" to "1-0"
summary(bank_data$response)
bank_data$response <- ifelse(bank_data$response == "yes", 1, 0)

# Check the numeric value of response rate in each bucket
agg_age <- merge(aggregate(response ~ binning.age, bank_data, mean),aggregate(response~binning.age, bank_data, sum),by = "binning.age") 

# Adding No.of_prospect
count <- data.frame(table(bank_data$binning.age))
count <- count[,-1]
agg_age <- cbind(agg_age,count)

# changing column name of each variables in agg_age dataframe
colnames(agg_age) <- c("age", "response_rate", "count_prospects","No.of_prospect")

# Round Off the values
agg_age$response_rate <- format(round(agg_age$response_rate, 2))

agg_age

#-------------------------------------------------------
# Writing a function "fn_plot_response" to do the same task for each variable
plot_response <- function(cat_var, var_name){
  a <- aggregate(response~cat_var, bank_data, mean)
  count <- data.frame(table(cat_var))
  count <- count[,-1]
  agg_response <- cbind(a, count)
  
  colnames(agg_response) <- c(var_name, "response_rate","No.of_Prospect")
  agg_response[, 2] <- format(round(agg_response[, 2], 2))
  
  ggplot(agg_response, aes(agg_response[, 1], count, label = response_rate)) + geom_bar(stat = 'identity') + theme(axis.text.x = element_text(angle = 60, hjust = 1)) + geom_text(size = 3, vjust = -0.5) + xlab(var_name)
  
}

plot_response(bank_data$binning.age, "Binning.age")

plot_response(bank_data$job, "job")

summary(bank_data$marital)
levels(bank_data$marital)[4] <- "married"

# Plotting marital status

plot_response(bank_data$marital,"marital")

plot_response(bank_data$education,"Education")

levels(bank_data$education)[c(1:3,5)] <- "Primary_Education"
levels(bank_data$education)[2] <- "Secondary_Education"
levels(bank_data$education)[4]<- "Tertiary_Education"

# Let's again check the education plot

plot_response(bank_data$education,"Education_levels")
#-------------------------------------------------------
# Let's see the default variable

table(bank_data$default)

plot_response(bank_data$default, "Default")
bank_data <- bank_data[,-5]

summary(bank_data$housing)
plot_response(bank_data$housing, "Housing")

summary(bank_data$loan)
plot_response(bank_data$loan, "Loan Status")

summary(bank_data$contact)
plot_response(bank_data$contact,"Contact_mode")

plot_response(bank_data$month,"Contact_month")

plot_response(bank_data$day_of_week,"day_of_week")

ggplot(bank_data,aes(duration))+geom_histogram()
# Let's see the summary of this variable once 
summary(bank_data$duration)

bank_data$response_1 <- as.factor(bank_data$response)
Avg_duration <- aggregate(duration~response_1,bank_data,mean)
Avg_duration
bank_data <- bank_data[,-22]

quantile(bank_data$duration,seq(0,1,0.01))

bank_data[(which(bank_data$duration>1271.13)),]$duration <- 1271.13

ggplot(bank_data,aes(duration))+geom_histogram()


summary(bank_data$campaign)
boxplot(bank_data$campaign)

quantile(bank_data$campaign,seq(0,1,0.01))

# Capping this at 99% which the value is 14
bank_data[which(bank_data$campaign>14),]$campaign <- 14

# Visualizing it with plot
ggplot(bank_data,aes(campaign))+geom_histogram()



bank_data$pdays<- as.factor(bank_data$pdays)

# Checking summary

summary(bank_data$pdays)

levels(bank_data$pdays)

# Reducing the levels of this variable to 3.

levels(bank_data$pdays)[1:10] <- "Contacted_in_first_10days"
levels(bank_data$pdays)[2:17] <-"Contacted_after_10days"
levels(bank_data$pdays)[3] <- "First_time_contacted"

plot_response(bank_data$pday,"Pday")
# Number of prospects under each category
table(bank_data$pdays)

summary(bank_data$previous)
# Max=7, best is to convert this variable to factor
bank_data$previous <- as.factor(bank_data$previous)

levels(bank_data$previous)[1]<-"Never contacted"
levels(bank_data$previous)[2:4] <- "Less_than_3_times"
levels(bank_data$previous)[3:6] <- "More than_3_times"


summary(bank_data$previous)
plot_response(bank_data$previous,"Previous_contacts")

summary(bank_data$poutcome)
plot_response(bank_data$poutcome,"Outcome_of_Previous_contacts")

summary(bank_data$emp.var.rate)
# Histogram of employment variation rate variable
ggplot(bank_data,aes(emp.var.rate))+geom_histogram()


# cons.price.idx:consumer price index - monthly indicator (numeric) 
summary(bank_data$cons.price.idx)
# Histogram of consumer price index variable
ggplot(bank_data,aes(cons.price.idx))+geom_histogram()

# cons.conf.idx: consumer confidence index - monthly indicator (numeric) 
summary(bank_data$cons.conf.idx)

# euribor3m: euribor 3 month rate - daily indicator (numeric)
summary(bank_data$euribor3m)

# nr.employed: number of employees - quarterly indicator (numeric)
summary(bank_data$nr.employed)

bank_data_RF <- bank_data

#------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------
#2.Build predictive models and choose the best one

## Model Building   
#--------------------------------------------------------------------------------------

# Required Packages

library(caret)
library(caTools)
library(dummies)

#---------------------------------------------------------    

# Removing binning variables 

bank_data <- bank_data[, -21]


#creating dummy variables

bank_data$response <- as.integer(bank_data$response)

k1 <- bank_data

bank_data <- dummy.data.frame(bank_data)

bank_data$response <- as.factor(ifelse(bank_data$response == 1, "yes", "no"))

#---------------------------------------------------------    

# splitting into train and test data

set.seed(1)

split_indices <- sample.split(bank_data$response, SplitRatio = 0.70)

train <- bank_data[split_indices, ]

test <- bank_data[!split_indices, ]

nrow(train)/nrow(bank_data)

nrow(test)/nrow(bank_data)

#---------------------------------------------------------    

### Model 1: Logistic Regression


library(MASS)

library(car)

logistic_1 <- glm(response ~ ., family = "binomial", data = train)

summary(logistic_1)

#---------------------------------------------------------    

# Using stepwise algorithm for removing insignificant variables 

logistic_2 <- stepAIC(logistic_1, direction = "both")

# stepAIC has removed some variables and only the following ones remain

logistic_2 <- glm(formula = response ~ age+jobadmin.+jobentrepreneur+jobhousemaid+jobmanagement+jobretired+jobservices+
                    jobstudent+jobtechnician+jobunemployed+maritaldivorced+maritalmarried+educationPrimary_Education+
                    educationprofessional.course+educationTertiary_Education+loanno+contactcellular+
                    monthapr+monthaug+monthjul+monthjun+monthmar+monthmay+monthnov+monthoct+day_of_weekfri+
                    day_of_weekmon+day_of_weekthu+campaign+pdaysContacted_in_first_10days+
                    pdaysContacted_after_10days+previousLess_than_3_times+poutcomefailure+emp.var.rate+
                    cons.price.idx+cons.conf.idx+euribor3m+nr.employed, family = "binomial", data = train)



# checking vif for logistic_2 

vif(logistic_2)

summary(logistic_2)

#---------------------------------------------------------    

# removing "previousLess_than_3_times"since vif is high and also the variable is not significant 

logistic_3 <- glm(formula = response ~ jobadmin. + jobentrepreneur + 
                    jobretired +
                    jobstudent + jobtechnician + jobunemployed + maritaldivorced + 
                    maritalmarried + educationPrimary_Education + educationprofessional.course + 
                    educationTertiary_Education + contactcellular + 
                    monthapr + monthaug + monthjul + monthjun + monthmar + monthmay + 
                    monthnov + monthoct + day_of_weekfri + day_of_weekmon + day_of_weekthu + 
                    campaign + pdaysContacted_in_first_10days + pdaysContacted_after_10days + 
                    previousLess_than_3_times + poutcomefailure + emp.var.rate + 
                    cons.price.idx + cons.conf.idx + euribor3m + nr.employed, 
                  family = "binomial", data = train)
summary(logistic_3)

vif(logistic_3)



logistic_4 <- glm(formula = response ~ jobadmin. + jobentrepreneur + jobretired + 
                    jobstudent + jobtechnician + maritaldivorced + 
                    educationPrimary_Education + 
                    educationTertiary_Education + contactcellular + monthapr + 
                    monthaug + monthjul + monthjun + monthmar + monthmay + monthnov + 
                    monthoct + day_of_weekfri + day_of_weekmon + 
                    campaign + pdaysContacted_in_first_10days + pdaysContacted_after_10days + 
                    previousLess_than_3_times + poutcomefailure + emp.var.rate + 
                    cons.price.idx + cons.conf.idx + nr.employed, 
                  family = "binomial", data = train)

summary(logistic_4)

vif(logistic_4)


logistic_5 <- glm(formula = response ~ jobadmin. + jobentrepreneur + jobretired + 
                    jobstudent + jobtechnician + maritaldivorced + educationPrimary_Education + 
                    educationTertiary_Education + contactcellular + monthapr + 
                    monthjul + monthjun + monthmar + monthmay + monthnov + 
                    monthoct + day_of_weekfri + day_of_weekmon + campaign + pdaysContacted_in_first_10days + 
                    pdaysContacted_after_10days + previousLess_than_3_times + 
                    poutcomefailure + emp.var.rate + cons.price.idx + cons.conf.idx + 
                    nr.employed, family = "binomial", data = train)

summary(logistic_5)



logistic_6 <- glm(formula = response ~ jobadmin. + jobretired + 
                    jobstudent + jobtechnician + maritaldivorced + educationPrimary_Education + 
                    educationTertiary_Education + contactcellular + monthapr + 
                    monthjul + monthjun + monthmar + monthmay + monthnov + monthoct + 
                    day_of_weekfri + day_of_weekmon + campaign + pdaysContacted_in_first_10days + 
                    pdaysContacted_after_10days + previousLess_than_3_times + 
                    poutcomefailure + emp.var.rate + cons.price.idx + cons.conf.idx + 
                    nr.employed, family = "binomial", data = train)


summary(logistic_6)



logistic_7 <- glm(formula = response ~ jobadmin. + jobretired + jobstudent + 
                    jobtechnician + maritaldivorced + educationPrimary_Education + 
                    educationTertiary_Education + contactcellular + monthapr + 
                    monthjul + monthjun + monthmar + monthmay + monthnov + monthoct + 
                    day_of_weekfri + day_of_weekmon + campaign + pdaysContacted_in_first_10days + 
                    pdaysContacted_after_10days +  
                    poutcomefailure + emp.var.rate + cons.price.idx + cons.conf.idx + 
                    nr.employed, family = "binomial", data = train)

summary(logistic_7)


# Removing "jobadmin."
logistic_8 <- glm(formula = response ~ jobretired + jobstudent + 
                    jobtechnician + maritaldivorced + educationPrimary_Education + 
                    educationTertiary_Education + contactcellular + monthapr + 
                    monthjul + monthjun + monthmar + monthmay + monthnov + monthoct + 
                    day_of_weekfri + day_of_weekmon + campaign + pdaysContacted_in_first_10days + 
                    pdaysContacted_after_10days + poutcomefailure + emp.var.rate + 
                    cons.price.idx + cons.conf.idx + nr.employed, family = "binomial", 
                  data = train)

summary(logistic_8)


# Removing "maritaldivorced"

logistic_9 <- glm(formula = response ~ jobretired + jobstudent + jobtechnician + 
                    educationPrimary_Education + educationTertiary_Education + 
                    contactcellular + monthapr + monthjul + monthjun + monthmar + 
                    monthmay + monthnov + monthoct + day_of_weekfri + day_of_weekmon + 
                    campaign + pdaysContacted_in_first_10days + pdaysContacted_after_10days + 
                    poutcomefailure + emp.var.rate + cons.price.idx + cons.conf.idx + 
                    nr.employed, family = "binomial", data = train)

summary(logistic_9)



# Removing "day_of_weekfri"

logistic_10 <- glm(formula = response ~ jobretired + jobstudent + jobtechnician + 
                     educationPrimary_Education + educationTertiary_Education + 
                     contactcellular + monthapr + monthjul + monthjun + monthmar + 
                     monthmay + monthnov + monthoct + day_of_weekmon + 
                     campaign + pdaysContacted_in_first_10days + pdaysContacted_after_10days + 
                     poutcomefailure + emp.var.rate + cons.price.idx + cons.conf.idx + 
                     nr.employed, family = "binomial", data = train)

summary(logistic_10)


# Removing "educationTertiary_Education" 

logistic_11 <- glm(formula = response ~ jobretired + jobstudent + jobtechnician + 
                     educationPrimary_Education +  
                     contactcellular + monthapr + monthjul + monthjun + monthmar + 
                     monthmay + monthnov + monthoct + day_of_weekmon + campaign + 
                     pdaysContacted_in_first_10days + pdaysContacted_after_10days + 
                     poutcomefailure + emp.var.rate + cons.price.idx + cons.conf.idx + 
                     nr.employed, family = "binomial", data = train)

summary(logistic_11)

# Removing "jobtechnician"

logistic_12 <- glm(formula = response ~ jobretired + jobstudent +  
                     educationPrimary_Education + contactcellular + monthapr + 
                     monthjul + monthjun + monthmar + monthmay + monthnov + monthoct + 
                     day_of_weekmon + campaign + pdaysContacted_in_first_10days + 
                     pdaysContacted_after_10days + poutcomefailure + emp.var.rate + 
                     cons.price.idx + cons.conf.idx + nr.employed, family = "binomial", 
                   data = train)

summary(logistic_12)

# Removing "monthoct"

logistic_13 <- glm(formula = response ~ jobretired + jobstudent + educationPrimary_Education + 
                     contactcellular + monthapr + monthjul + monthjun + monthmar + 
                     monthmay + monthnov + day_of_weekmon + campaign + 
                     pdaysContacted_in_first_10days + pdaysContacted_after_10days + 
                     poutcomefailure + emp.var.rate + cons.price.idx + cons.conf.idx + 
                     nr.employed, family = "binomial", data = train)

summary(logistic_13)


#removing jobstudent
logistic_14 <- glm(formula = response ~ jobretired + educationPrimary_Education + 
                     contactcellular + monthapr + monthjul + monthjun + monthmar + 
                     monthmay + monthnov + day_of_weekmon + campaign + pdaysContacted_in_first_10days + 
                     pdaysContacted_after_10days + poutcomefailure + emp.var.rate + 
                     cons.price.idx + cons.conf.idx + nr.employed, family = "binomial", 
                   data = train)


summary(logistic_14)


#removing monthjul
logistic_15 <- glm(formula = response ~ jobretired + educationPrimary_Education + 
                     contactcellular + monthapr + monthjun + monthmar + 
                     monthmay + monthnov + day_of_weekmon + campaign + pdaysContacted_in_first_10days + 
                     pdaysContacted_after_10days + poutcomefailure + emp.var.rate + 
                     cons.price.idx + cons.conf.idx + nr.employed, family = "binomial", 
                   data = train)

summary(logistic_15)

#removing "monthapr"
logistic_16 <- glm(formula = response ~ jobretired + educationPrimary_Education + 
                     contactcellular + monthjun + monthmar + monthmay + 
                     monthnov + day_of_weekmon + campaign + pdaysContacted_in_first_10days + 
                     pdaysContacted_after_10days + poutcomefailure + emp.var.rate + 
                     cons.price.idx + cons.conf.idx + nr.employed, family = "binomial", 
                   data = train)

summary(logistic_16)

#removing "nr.employed"
logistic_17 <- glm(formula = response ~ jobretired + educationPrimary_Education + 
                     contactcellular + monthjun + monthmar + monthmay + monthnov + 
                     day_of_weekmon + campaign + pdaysContacted_in_first_10days + 
                     pdaysContacted_after_10days + poutcomefailure + emp.var.rate + 
                     cons.price.idx + cons.conf.idx, family = "binomial", 
                   data = train)

summary(logistic_17)

#Coefficients:
#  Estimate Std. Error z value Pr(>|z|)    
#(Intercept)                    -1.013e+02  5.317e+00 -19.055  < 2e-16 ***
#  jobretired                      3.082e-01  8.449e-02   3.648 0.000264 ***
#  educationPrimary_Education     -1.708e-01  4.940e-02  -3.457 0.000546 ***
#  contactcellular                 6.156e-01  6.833e-02   9.009  < 2e-16 ***
#  monthjun                       -2.706e-01  7.580e-02  -3.570 0.000356 ***
#  monthmar                        1.082e+00  1.170e-01   9.251  < 2e-16 ***
#  monthmay                       -6.483e-01  5.883e-02 -11.021  < 2e-16 ***
#  monthnov                       -4.775e-01  7.579e-02  -6.300 2.98e-10 ***
#  day_of_weekmon                 -2.924e-01  5.380e-02  -5.434 5.52e-08 ***
#  campaign                       -4.869e-02  1.186e-02  -4.107 4.01e-05 ***
#  pdaysContacted_in_first_10days  1.337e+00  8.444e-02  15.840  < 2e-16 ***
#  pdaysContacted_after_10days     1.180e+00  1.776e-01   6.642 3.08e-11 ***
#  poutcomefailure                -5.858e-01  6.554e-02  -8.938  < 2e-16 ***
#  emp.var.rate                   -7.487e-01  2.093e-02 -35.775  < 2e-16 ***
#  cons.price.idx                  1.071e+00  5.720e-02  18.716  < 2e-16 ***
#  cons.conf.idx                   2.882e-02  4.209e-03   6.847 7.56e-12 ***



logistic_final <- logistic_17

#---------------------------------------------------------    

# Predicting probabilities of responding for the test data

predictions_logit <- predict(logistic_final, newdata = test[, -61], type = "response")



#---------------------------------------------------------------------------
#3. Create a data frame with the variables prospect ID, actual response, 
#predicted response, predicted probability of response, duration of call in 
#seconds, and cost of call

#While creating the data frame, calculate the cost of call for each 
#prospect in a new column

df_predictions_logit <- as.data.frame(predictions_logit)

df_predictions_logit$prospect_ID <- seq.int(nrow(df_predictions_logit))

df_predictions_logit$actual_response <- factor(ifelse(test$response == "yes", 1, 0))

df_predictions_logit$predicted_probability_of_response <- factor(ifelse(predictions_logit >= 0.50, 1, 0))

df_predictions_logit$duration_of_call_in_seconds <- test$duration

df_predictions_logit <- df_predictions_logit[,c(2,3,1,4,5)]

df_predictions_logit$cost_of_call_in_INR <- 0.033*(test$duration) + 0.8

head(df_predictions_logit)
#--------------------------------------------------------- 
#---------------------------------------------------------------------------

## Model Evaluation: Logistic Regression

# Let's use the probability cutoff of 50%.

predicted_response <- factor(ifelse(predictions_logit >= 0.50, "yes", "no"))
# Creating confusion matrix for identifying the model evaluation.

conf <- confusionMatrix(predicted_response, test$response, positive = "yes")

conf

#Confusion Matrix and Statistics

#Reference
#Prediction    no   yes
#no  10798  1078
#yes   166   314

#Accuracy : 0.8993          
#95% CI : (0.8939, 0.9046)
#No Information Rate : 0.8873          
#P-Value [Acc > NIR] : 1.018e-05       

#Kappa : 0.2947          
#Mcnemar's Test P-Value : < 2.2e-16       

#Sensitivity : 0.22557         
#Specificity : 0.98486   

#in the above result sensitivity is very low so we will find the right cut off parameter

#---------------------------------------------------------    

# Let's find out the optimal probalility cutoff 

perform_fn <- function(cutoff) 
{
  predicted_response <- factor(ifelse(predictions_logit >= cutoff, "yes", "no"))
  conf <- confusionMatrix(predicted_response, test$response, positive = "yes")
  acc <- conf$overall[1]
  sens <- conf$byClass[1]
  spec <- conf$byClass[2]
  out <- t(as.matrix(c(sens, spec, acc))) 
  colnames(out) <- c("sensitivity", "specificity", "accuracy")
  return(out)
}

#---------------------------------------------------------    

# Creating cutoff values from 0.01 to 0.99 for plotting and initiallizing a matrix of 1000 X 4.

s = seq(.01,.99,length=100)

OUT = matrix(0,100,3)


for(i in 1:100)
{
  OUT[i,] = perform_fn(s[i])
}

#---------------------------------------------------------    

# plotting cutoffs 
plot(s, OUT[,1],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)
axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
lines(s,OUT[,2],col="darkgreen",lwd=2)
lines(s,OUT[,3],col=4,lwd=2)
box()
legend(.50,.50,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))


#---------------------------------------------------------    

cutoff <- s[which(abs(OUT[,1]-OUT[,2])<0.01)]


# Let's choose a cutoff value of 12% for final model

conf_final <- confusionMatrix(predicted_response, test$response, positive = "yes")

acc <- conf_final$overall[1]

sens <- conf_final$byClass[1]

spec <- conf_final$byClass[2]

acc

sens

spec

#Accuracy : 0.8993202 
#Sensitivity  : 0.2255747 
#Specificity  : 0.9848595 
#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
# ------Model Evaluation for logistic regression model -----------------------
#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
#-----------------------------------------------------------------------------
#---------------------------------------------------------    

# Creating new dataframe "test_predictions_glm"

test_predictions_glm <- df_predictions_logit[, c("actual_response", "predictions_logit", "predicted_probability_of_response")]


response_rate <- table(test$response)[2]/(table(test$response)[1] + table(test$response)[2])

# sorting the probabilities in decreasing order 
test_predictions_glm <- test_predictions_glm[order(test_predictions_glm$predictions_logit, decreasing = T), ]

#Downloading the data 
#write.csv(test_predictions_rf,"test_prediction_rf.csv")

summary(test_predictions_glm$actual_response[1:6800])

# plotting the lift chart

# Loading dplyr package 
require(dplyr)
library(dplyr)

lift <- function(labels , predicted_prob, groups=10) {
  
  if(is.factor(labels)) labels  <- as.integer(as.character(labels ))
  if(is.factor(predicted_prob)) predicted_prob <- as.integer(as.character(predicted_prob))
  helper = data.frame(cbind(labels , predicted_prob))
  helper[,"bucket"] = ntile(-helper[,"predicted_prob"], groups)
  gaintable = helper %>% group_by(bucket)  %>%
    summarise_at(vars(labels ), funs(total = n(),
                                     totalresp=sum(., na.rm = TRUE))) %>%
    mutate(Cumresp = cumsum(totalresp),
           Gain=Cumresp/sum(totalresp)*100,
           Cumlift=Gain/(bucket*(100/groups)))
  return(gaintable)
}

# Create a Table of cumulative gain and lift 

test_predictions_glm$actual_response <- as.factor(test_predictions_glm$actual_response)

LG = lift(test_predictions_glm$actual_response, test_predictions_glm$predictions_logit, groups = 10)

# Gain Chart 

plot(LG$bucket,LG$Gain,col="red",type="l",main="Gain Chart : logistic regression model",xlab="% of total targeted",ylab = "% of positive Response")

# Lift Chart 

plot(LG$bucket,LG$Cumlift,col="red",type="l",main="Lift Chart : logistic regression model",xlab="% of total targeted",ylab = "Lift")

# Total Cost incur throught direct telemarketing 

# Let's say if you have spent 1Re for each customer
View(LG)

#--------------------------------------------------------- 

#4. Find the number of top X% prospects you should target to meet the business objective
#Report the average call duration for targeting the top X% prospects to the CMO (report this as a comment in the R file)

# by contacting 6175 customers to achive 80% responders.

#In conclusion, the Cumulative Lift of 13.3 for top 5 deciles is the resultant 
#when selecting 80% of the records based on the model, where one can expect 5 
#times the total number of targets (1235) is 6175


#--------------------------------------------------------- 
#--------------------------------------------------------- 
#--------------------------------------------------------- 
#--------------------------------------------------------- 
#--------------------------------------------------------- 
#--------------------------------------------------------- 
# ----Model Building - Model 3:- Random forest
#--------------------------------------------------------- 
#--------------------------------------------------------- 
#--------------------------------------------------------- 
#--------------------------------------------------------- 
#--------------------------------------------------------- 
#--------------------------------------------------------- 

# Package required for randomForest algorithm is:
# install randomForest
library(randomForest)
library(ggplot2)
#---------------------------------------------------------    

# Spliting the bank data in 70:30 ratio

unique(bank_data_raw$response)
bank <- bank_data_raw

set.seed(100)

split_indices <- sample.split(bank$response, SplitRatio = 0.70)

train_rf <- bank[split_indices, ]

test_rf <- bank[!split_indices, ]

nrow(train_rf)/nrow(bank)

nrow(test_rf)/nrow(bank)

#---------------------------------------------------------    

# Building the model in this we have removed "duration"

bank_rf <- randomForest(response ~., data = train_rf[, -11], proximity = F, do.trace = T, mtry = 5)

# Predict response for test data

rf_pred <- predict(bank_rf, test_rf[, -11], type = "prob")
#---------------------------------------------------------    

# Cutoff for randomforest to assign yes or no

perform_fn_rf <- function(cutoff) 
{
  predicted_response <- as.factor(ifelse(rf_pred[, 2] >= cutoff, "no", "yes"))
  conf <- confusionMatrix(predicted_response, test_rf$response, positive = "yes")
  acc <- conf$overall[1]
  sens <- conf$byClass[1]
  spec <- conf$byClass[2]
  OUT_rf <- t(as.matrix(c(sens, spec, acc))) 
  colnames(OUT_rf) <- c("sensitivity", "specificity", "accuracy")
  return(OUT_rf)
}

#---------------------------------------------------------    

# creating cutoff values from 0.01 to 0.99 for plotting and initialising a matrix of size 1000x4
s = seq(.01,.99,length=100)

OUT_rf = matrix(0,100,3)

# calculate the sens, spec and acc for different cutoff values

for(i in 1:100)
{
  OUT_rf[i,] = perform_fn_rf(s[i])
}

#---------------------------------------------------------    

# plotting cutoffs

plot(s, OUT_rf[,1],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)
axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
lines(s,OUT_rf[,2],col="darkgreen",lwd=2)
lines(s,OUT_rf[,3],col=4,lwd=2)
box()

legend(.50,.50,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))

cutoff_rf <- s[which(abs(OUT_rf[,1]-OUT_rf[,2])<0.01)]

# The plot shows that cutoff value of around 25% optimises sensitivity and accuracy

predicted_response_22 <- factor(ifelse(rf_pred[, 2] >= 0.26, "yes", "no"))

conf_forest <- confusionMatrix(predicted_response_22, test_rf$response, positive = "yes")

conf_forest

# Sensitivity
conf_forest$byClass[1]

# Specificity 
conf_forest$byClass[2]

# Accuracy 
conf_forest$overall[1]

#Confusion Matrix and Statistics

#Reference
#Prediction    no   yes
#no  10035   664
#yes   929   728

#Accuracy : 0.8716413        
#Sensitivity : 0.5251437        
#Specificity : 0.915633

#--------------------------------------------------------------------------

# Final RF important variables
importance <- bank_rf$importance 

importance <- data.frame(importance)

#MeanDecreaseGini
importance
#-----------------------------------------------------------------------------
#--------------------------------------------------------- 
#--------------------------------------------------------- 
#---------------------------------------------------------    
# ------Model Evaluation randomForest----------------------
#--------------------------------------------------------- 
#--------------------------------------------------------- 
#---------------------------------------------------------    
#-----------------------------------------------------------------------------

# Appending the probabilities and response variables to the test data

test_rf$predicted_probs <- rf_pred[, 2]

test_rf$predicted_response <- predicted_response_22

#---------------------------------------------------------    

# Creating new dataframe "test_predictions_rf"

test_predictions_rf <- test_rf[, c("response", "predicted_probs", "predicted_response")]


summary(test_predictions_rf$response)
summary(test_predictions_rf$predicted_response)


response_rate <- table(test$response)[2]/(table(test$response)[1] + table(test$response)[2])

# sorting the probabilities in decreasing order 
test_predictions_rf <- test_predictions_rf[order(test_predictions_rf$predicted_probs, decreasing = T), ]

#Downloading the data 
#write.csv(test_predictions_rf,"test_prediction_rf.csv")

summary(test_predictions_rf$response[1:6800])
summary(test_predictions_rf$predicted_response[1:6800])

# plotting the lift chart

# Loading dplyr package 
require(dplyr)
library(dplyr)

lift <- function(labels , predicted_prob, groups=10) {
  
  if(is.factor(labels)) labels  <- as.integer(as.character(labels ))
  if(is.factor(predicted_prob)) predicted_prob <- as.integer(as.character(predicted_prob))
  helper = data.frame(cbind(labels , predicted_prob))
  helper[,"bucket"] = ntile(-helper[,"predicted_prob"], groups)
  gaintable = helper %>% group_by(bucket)  %>%
    summarise_at(vars(labels ), funs(total = n(),
                                     totalresp=sum(., na.rm = TRUE))) %>%
    mutate(Cumresp = cumsum(totalresp),
           Gain=Cumresp/sum(totalresp)*100,
           Cumlift=Gain/(bucket*(100/groups)))
  return(gaintable)
}

# Create a Table of cumulative gain and lift 

test_predictions_rf$response <- as.factor(ifelse(test_predictions_rf$response=="yes",1,0))

LG = lift(test_predictions_rf$response, test_predictions_rf$predicted_probs, groups = 10)

# Gain Chart 

plot(LG$bucket,LG$Gain,col="red",type="l",main="Gain Chart : randomForest",xlab="% of total targeted",ylab = "% of positive Response")

# Lift Chart 

plot(LG$bucket,LG$Cumlift,col="red",type="l",main="Gain Chart : randomForest",xlab="% of total targeted",ylab = "Lift")

# Total Cost incur throught direct telemarketing 

# Let's say if you have spent 1Re for each customer
View(LG)

#---------------------------------------------------------------------------
#4. Find the number of top X% prospects you should target to meet the business objective
#Report the average call duration for targeting the top X% prospects to the CMO (report this as a comment in the R file)

# by contacting 7416 customers to achive 80% responders.

#In conclusion, the Cumulative Lift of 13.3 for top 6 deciles is the resultant 
#when selecting 80% of the records based on the model, where one can expect 6
#times the total number of targets (1236) is 7416

#-----------------------------------------------------------------------------
#--------------------------------------------------------- 
#---------------------------------------------------------