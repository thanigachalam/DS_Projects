# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------
###################### NYC Parking Tickets: An Exploratory Analysis###########
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------
# Load SparkR
spark_path <- '/usr/local/spark'
if (nchar(Sys.getenv("SPARK_HOME")) < 1) {
  Sys.setenv(SPARK_HOME = spark_path)
}
library(SparkR, lib.loc = c(file.path(Sys.getenv("SPARK_HOME"), "R", "lib")))

# Initialise the sparkR session
sparkR.session(master = "yarn-client", sparkConfig = list(spark.driver.memory = "1g"))

# Create a Spark DataFrame and examine structure
data_nyc_2015 <- read.df("/common_folder/nyc_parking/Parking_Violations_Issued_-_Fiscal_Year_2015.csv", source = "csv",
                    header = TRUE, inferSchema = TRUE)

data_nyc_2016 <- read.df("/common_folder/nyc_parking/Parking_Violations_Issued_-_Fiscal_Year_2016.csv", source = "csv",
                         header = TRUE, inferSchema = TRUE)

data_nyc_2017 <- read.df("/common_folder/nyc_parking/Parking_Violations_Issued_-_Fiscal_Year_2017.csv", source = "csv",
                         header = TRUE, inferSchema = TRUE)

#----------------------------------------------------------------
# Basic understanding of data
#----------------------------------------------------------------
#nrow(data_nyc_2015) #11809233
#nrow(data_nyc_2016) #10626899
#nrow(data_nyc_2017) #10803028

#head(data_nyc_2015)
#head(data_nyc_2016)
#head(data_nyc_2017)

#ncol(data_nyc_2015)
#ncol(data_nyc_2016)
#ncol(data_nyc_2017)

#str(data_nyc_2015)
#str(data_nyc_2016)
#str(data_nyc_2017)

data_nyc_2015$Issue_Date_unixtime <- unix_timestamp(data_nyc_2015$`Issue Date`, 'MM/dd/yyyy') #to_date(data_nyc_2015$`Issue Date`)
data_nyc_2015$Issue_Date_ts <- cast(data_nyc_2015$Issue_Date_unixtime, 'timestamp') #to_date(data_nyc_2015$`Issue Date`)
data_nyc_2015$Issue_Date_dt <- cast(data_nyc_2015$Issue_Date_ts, 'date')
data_nyc_2015$Issue_Date_yr <- year(data_nyc_2015$Issue_Date_dt)
data_nyc_2015$Issue_Date_mm <- month(data_nyc_2015$Issue_Date_dt)

d2015 <- filter(data_nyc_2015, "Issue_Date_yr == 2015")

#nrow(d2015) #5986831

#------------------------------------

data_nyc_2016$Issue_Date_unixtime <- unix_timestamp(data_nyc_2016$`Issue Date`, 'MM/dd/yyyy')
data_nyc_2016$Issue_Date_ts <- cast(data_nyc_2016$Issue_Date_unixtime, 'timestamp')
data_nyc_2016$Issue_Date_dt <- cast(data_nyc_2016$Issue_Date_ts, 'date')
data_nyc_2016$Issue_Date_yr <- year(data_nyc_2016$Issue_Date_dt)
data_nyc_2016$Issue_Date_mm <- month(data_nyc_2016$Issue_Date_dt)

d2016 <- filter(data_nyc_2016, "Issue_Date_yr == 2016")

#nrow(d2016) #4872621

#------------------------------------------

data_nyc_2017$Issue_Date_unixtime <- unix_timestamp(data_nyc_2017$`Issue Date`, 'MM/dd/yyyy') 
data_nyc_2017$Issue_Date_ts <- cast(data_nyc_2017$Issue_Date_unixtime, 'timestamp')
data_nyc_2017$Issue_Date_dt <- cast(data_nyc_2017$Issue_Date_ts, 'date')
data_nyc_2017$Issue_Date_yr <- year(data_nyc_2017$Issue_Date_dt)
data_nyc_2017$Issue_Date_mm <- month(data_nyc_2017$Issue_Date_dt)

d2017 <- filter(data_nyc_2017, "Issue_Date_yr == 2017")

#nrow(d2017) #5431918
#-------------------------------------------
cols <- c("Summons Number","Plate ID","Registration State","Plate Type","Issue Date",
          "Violation Code","Vehicle Body Type","Vehicle Make","Issuing Agency",
          "Street Code1","Street Code2","Street Code3","Vehicle Expiration Date",
          "Issuer Code","Issuer Command","Violation Location","Violation Precinct",
          "Issuer Precinct","Issuer Squad","Violation Time","Time First Observed",
          "Violation County","Violation In Front Of Or Opposite","House Number",
          "Street Name","Intersecting Street","Date First Observed","Law Section",
          "Sub Division","Violation Legal Code","Days Parking In Effect    ",
          "From Hours In Effect","To Hours In Effect","Vehicle Color",
          "Unregistered Vehicle?","Vehicle Year","Meter Number","Feet From Curb",
          "Violation Post Code","Violation Description","No Standing or Stopping Violation",
          "Hydrant Violation","Double Parking Violation","Issue_Date_dt","Issue_Date_yr","Issue_Date_mm")

dat2015 <- select(d2015, cols)

dat2016 <- select(d2016, cols)

dat2017 <- select(d2017, cols)

dat2015$Issue_Date_qtr <- ifelse(
  dat2015$Issue_Date_mm <= 3, 'Quarter_1', 
  ifelse(dat2015$Issue_Date_mm > 3 & dat2015$Issue_Date_mm <=6, 'Quarter_2', 
         ifelse(dat2015$Issue_Date_mm > 6 & dat2015$Issue_Date_mm <=9, 'Quarter_3', 
                ifelse(dat2015$Issue_Date_mm > 9 & dat2015$Issue_Date_mm <=12, 'Quarter_4', 'NA'))))

#nrow(d2015) #5986831

dat2016$Issue_Date_qtr <- ifelse(
  dat2016$Issue_Date_mm <= 3, 'Quarter_1', 
  ifelse(dat2016$Issue_Date_mm > 3 & dat2016$Issue_Date_mm <=6, 'Quarter_2', 
         ifelse(dat2016$Issue_Date_mm > 6 & dat2016$Issue_Date_mm <=9, 'Quarter_3', 
                ifelse(dat2016$Issue_Date_mm > 9 & dat2016$Issue_Date_mm <=12, 'Quarter_4', 'NA'))))

dat2017$Issue_Date_qtr <- ifelse(
  dat2017$Issue_Date_mm <= 3, 'Quarter_1', 
  ifelse(dat2017$Issue_Date_mm > 3 & dat2017$Issue_Date_mm <=6, 'Quarter_2', 
         ifelse(dat2017$Issue_Date_mm > 6 & dat2017$Issue_Date_mm <=9, 'Quarter_3', 
                ifelse(dat2017$Issue_Date_mm > 9 & dat2017$Issue_Date_mm <=12, 'Quarter_4', 'NA'))))

#nrow(dat2015) #5986831

#removing duplicate values
final_dat2015 <- dropDuplicates(dat2015, "Summons Number")

nrow(final_dat2015) #5373971

#removing duplicate values
final_dat2016 <- dropDuplicates(dat2016, "Summons Number")

nrow(final_dat2016) #4872621

#removing duplicate values
final_dat2017 <- dropDuplicates(dat2017, "Summons Number")

nrow(final_dat2017) #5431918

#dim(final_dat2015)
#dim(final_dat2016)
#dim(final_dat2017)

#-------------------------------------------------------------------------------
#validating for Missing Values or NA in percentage
#-----------------------------------------------------------------------------------

#fractions <- select(dat2015, lapply(columns(dmain), function(c) alias(avg(cast(isNotNull(dmain[[c]]), "integer")), c)))
#head(fractions)

#As per the above analysis we will be removing the following columns since there is no records

#No Standing or Stopping Violation : 1
#Hydrant Violation : 1
#Double Parking Violation : 1 need to check
#Latitude : 0
#Longitude : 0                                                                              0
#Community Board : 0
#Community Council  : 0 #some error
#Census Tract : 0
#BIN : 0
#BBL : 0
#NTA : 0


#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
#EDA:
#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------

# Before executing any hive-sql query from RStudio, you need to add a jar file in RStudio 
sql("ADD JAR /opt/cloudera/parcels/CDH/lib/hive/lib/hive-hcatalog-core-1.1.0-cdh5.11.2.jar")

# For using SQL, you need to create a temporary view
createOrReplaceTempView(final_dat2015, "final_dat2015")
#nrow(final_dat2015)

createOrReplaceTempView(final_dat2016, "final_dat2016")
#nrow(final_dat2016)

createOrReplaceTempView(final_dat2017, "final_dat2017")
#nrow(final_dat2017)

#removing dataframes which is not required anymore.
rm(data_nyc_2015)
rm(data_nyc_2016)
rm(data_nyc_2017)
rm(d2015)
rm(d2016)
rm(d2017)
rm(dat2015)
rm(dat2016)
rm(dat2017)

#-------------------------------------------------------------------------------------------------
#-------------------------------------------------------------------------------------------------
############################# Examine the data ###########################
#-------------------------------------------------------------------------------------------------
#-------------------------------------------------------------------------------------------------
## 1. Find the total number of tickets for each year.
TOTAL_TICKET_2015 <- SparkR::sql("select Issue_Date_yr,count(1) Ticket_Count from final_dat2015 group by Issue_Date_yr")

TOTAL_TICKET_2016 <- SparkR::sql("select Issue_Date_yr,count(1) Ticket_Count from final_dat2016 group by Issue_Date_yr")

TOTAL_TICKET_2017 <- SparkR::sql("select Issue_Date_yr,count(1) Ticket_Count from final_dat2017 group by Issue_Date_yr")

df_ttcnt_2015 <- data.frame(head(TOTAL_TICKET_2015, nrow(TOTAL_TICKET_2015)))
df_ttcnt_2016 <- data.frame(head(TOTAL_TICKET_2016, nrow(TOTAL_TICKET_2016)))
df_ttcnt_2017 <- data.frame(head(TOTAL_TICKET_2017, nrow(TOTAL_TICKET_2017)))

df_ttcnt <- rbind(df_ttcnt_2015,df_ttcnt_2016,df_ttcnt_2017)
library(ggplot2)
ggplot(df_ttcnt, aes(x= as.factor(Issue_Date_yr), y=Ticket_Count))+ geom_col() + xlab("Year") + ylab("Total Number of Tickets") + ggtitle("Total number of tickets for each year") + geom_text(aes(label=Ticket_Count),vjust=-0.3)

#----------------------------------------------------------------------------
#----------------------------------------------------------------------------
#https://www.dmvlist.com/
#https://en.wikipedia.org/wiki/United_States_license_plate_designs_and_serial_formats

#State_Code <- c('AL','AK','AZ','AR','CA','CO','CT','DE','DC','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY')

#2.Find out the number of unique states from where the cars that got 
#parking tickets came from. (Hint: Use the column 'Registration State')

#There is a numeric entry in the column which should be corrected. 
#Replace it with the state having maximum entries. Give the number 
#of unique states for each year again.
statewise_min_2015_test <- SparkR::sql("select 
                                   `Registration State` Registration_State,
                                   count(1) Ticket_Count 
                                   from final_dat2015 
                                   where `Registration State` IN ('AL','AK','AZ','AR','CA','CO','CT','DE','DC','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY') 
                                   group by Registration_State
                                   order by Ticket_Count desc limit 1")

#head(statewise_min_2015_test)
#  Registration_State Ticket_Count                                               
#1                 NY      4201307

statewise_2015 <- SparkR::sql("select 
	Issue_Date_yr,
                              Registration_State,
                              sum(Ticket_Count) Ticket_Count 
                              from (
                              select Issue_Date_yr, 
                              case when Registration_State = 'NA' then 'NY' ELSE Registration_State END Registration_State, 
                              Ticket_Count  
                              from ( 
                              select Issue_Date_yr, 
                              Registration_State, 
                              count(1) Ticket_Count from (select 
                              Issue_Date_yr,
                              CASE WHEN `Registration State` NOT IN ('AL','AK','AZ','AR','CA','CO','CT','DE','DC','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY') THEN 'NA' ELSE `Registration State` END AS Registration_State 
                              from final_dat2015 ) a
                              group by Issue_Date_yr,Registration_State
                              ) b 
                              ) c group by Issue_Date_yr,Registration_State")

df_statewise_2015 <- data.frame(head(statewise_2015, nrow(statewise_2015)))

df_statewise_2015

#-------------------
statewise_min_2016_test <- SparkR::sql("select 
                                   `Registration State` Registration_State,
                                       count(1) Ticket_Count 
                                       from final_dat2016
                                       where `Registration State` IN ('AL','AK','AZ','AR','CA','CO','CT','DE','DC','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY') 
                                       group by Registration_State
                                       order by Ticket_Count desc limit 1")

#head(statewise_min_2016_test)
#  Registration_State Ticket_Count                                               
#1                 NY      3784263

statewise_2016 <- SparkR::sql("select 
                              Issue_Date_yr,
                              Registration_State,
                              sum(Ticket_Count) Ticket_Count 
                              from (
                              select Issue_Date_yr, 
                              case when Registration_State = 'NA' then 'NY' ELSE Registration_State END Registration_State, 
                              Ticket_Count  
                              from ( 
                              select Issue_Date_yr, 
                              Registration_State, 
                              count(1) Ticket_Count from (select 
                              Issue_Date_yr,
                              CASE WHEN `Registration State` NOT IN ('AL','AK','AZ','AR','CA','CO','CT','DE','DC','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY') THEN 'NA' ELSE `Registration State` END AS Registration_State 
                              from final_dat2016 ) a
                              group by Issue_Date_yr,Registration_State
                              ) b 
                              ) c group by Issue_Date_yr,Registration_State")

df_statewise_2016<- data.frame(head(statewise_2016, nrow(statewise_2016)))

df_statewise_2016

#--------------------------
statewise_min_2017_test <- SparkR::sql("select 
                                   `Registration State` Registration_State,
                                       count(1) Ticket_Count 
                                       from final_dat2017
                                       where `Registration State` IN ('AL','AK','AZ','AR','CA','CO','CT','DE','DC','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY') 
                                       group by Registration_State
                                       order by Ticket_Count desc limit 1")

#head(statewise_min_2017_test)
#Registration_State Ticket_Count                                               
#1                 NY      4273951

statewise_2017 <- SparkR::sql("select 
                              Issue_Date_yr,
                              Registration_State,
                              sum(Ticket_Count) Ticket_Count 
                              from (
                              select Issue_Date_yr, 
                              case when Registration_State = 'NA' then 'NY' ELSE Registration_State END Registration_State, 
                              Ticket_Count  
                              from ( 
                              select Issue_Date_yr, 
                              Registration_State, 
                              count(1) Ticket_Count from (select 
                              Issue_Date_yr,
                              CASE WHEN `Registration State` NOT IN ('AL','AK','AZ','AR','CA','CO','CT','DE','DC','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY') THEN 'NA' ELSE `Registration State` END AS Registration_State 
                              from final_dat2017 ) a
                              group by Issue_Date_yr,Registration_State
                              ) b 
                              ) c group by Issue_Date_yr,Registration_State")

df_statewise_2017<- data.frame(head(statewise_2017, nrow(statewise_2017)))

df_statewise_2017

#--------------------------
ggplot(df_statewise_2015, aes(x= as.factor(Registration_State), y=Ticket_Count))+ geom_col() + xlab("Registration State") + ylab("Total Number of Tickets") + ggtitle("Total number of tickets by Car Registration State - 2015")
ggplot(df_statewise_2016, aes(x= as.factor(Registration_State), y=Ticket_Count))+ geom_col() + xlab("Registration State") + ylab("Total Number of Tickets") + ggtitle("Total number of tickets by Car Registration State - 2016")
ggplot(df_statewise_2017, aes(x= as.factor(Registration_State), y=Ticket_Count))+ geom_col() + xlab("Registration State") + ylab("Total Number of Tickets") + ggtitle("Total number of tickets by Car Registration State - 2017")

#------------------------------------------------------------------------------
#------------------------------------------------------------------------------
#3.Some parking tickets don’t have the address for violation location on them, 
#which is a cause for concern. Write a query to check the number of such tickets.

#The values should not be deleted or imputed here. This is just a check.

No_Address_Violatn_2015 <- SparkR::sql("SELECT Issue_Date_yr, count(`Summons Number`) Number_of_No_Address_violation FROM final_dat2015 where `Violation Location` is null group by Issue_Date_yr")

df_No_Address_Violatn_2015<- data.frame(head(No_Address_Violatn_2015, nrow(No_Address_Violatn_2015)))

df_No_Address_Violatn_2015
## 721275 with no address for violation location
#-----------
No_Address_Violatn_2016 <- SparkR::sql("SELECT Issue_Date_yr, count(`Summons Number`) Number_of_No_Address_violation FROM final_dat2016 where `Violation Location` is null group by Issue_Date_yr")

df_No_Address_Violatn_2016<- data.frame(head(No_Address_Violatn_2016, nrow(No_Address_Violatn_2016)))

df_No_Address_Violatn_2016
#---------
No_Address_Violatn_2017 <- SparkR::sql("SELECT Issue_Date_yr, count(`Summons Number`) Number_of_No_Address_violation FROM final_dat2017 where `Violation Location` is null group by Issue_Date_yr")

df_No_Address_Violatn_2017<- data.frame(head(No_Address_Violatn_2017, nrow(No_Address_Violatn_2017)))

df_No_Address_Violatn_2017

df_No_Address_Violatn <- rbind(df_No_Address_Violatn_2015,df_No_Address_Violatn_2016,df_No_Address_Violatn_2017)

ggplot(df_No_Address_Violatn, aes(x= as.factor(Issue_Date_yr), y=Number_of_No_Address_violation))+ geom_col() + xlab("Year") + ylab("Number_of_No_Address_violation") + ggtitle("Total number of No_Address_violation")+ geom_text(aes(label=Number_of_No_Address_violation),vjust=-0.3)

#------------------------------------------------------------------------------
#------------------------------------------------------------------------------
#------------------------------------------------------------------------------
############################ Aggregation tasks #############################
#------------------------------------------------------------------------------
#----------------------------------------------------------------------------
#----------------------------------------------------------------------------
#1.How often does each violation code occur? 
#Display the frequency of the top five violation codes.

Violatn_frequency_2015 <- SparkR::sql("SELECT Issue_Date_yr,`Violation Code` Violation_Code, count(`Violation Code`) Number_Of_Violation FROM final_dat2015 group by Issue_Date_yr,Violation_Code order by  Number_Of_Violation desc limit 5 ")

df_Violatn_frequency_2015<- data.frame(head(Violatn_frequency_2015, nrow(Violatn_frequency_2015)))

df_Violatn_frequency_2015
#----------
Violatn_frequency_2016 <- SparkR::sql("SELECT Issue_Date_yr,`Violation Code` Violation_Code, count(`Violation Code`) Number_Of_Violation FROM final_dat2016 group by Issue_Date_yr,Violation_Code order by  Number_Of_Violation desc limit 5 ")

df_Violatn_frequency_2016<- data.frame(head(Violatn_frequency_2016, nrow(Violatn_frequency_2016)))

df_Violatn_frequency_2016
#----------
Violatn_frequency_2017 <- SparkR::sql("SELECT Issue_Date_yr,`Violation Code` Violation_Code, count(`Violation Code`) Number_Of_Violation FROM final_dat2017 group by Issue_Date_yr,Violation_Code order by  Number_Of_Violation desc limit 5 ")

df_Violatn_frequency_2017<- data.frame(head(Violatn_frequency_2017, nrow(Violatn_frequency_2017)))

df_Violatn_frequency_2017
#------
df_Violatn_frequency <- rbind(df_Violatn_frequency_2015,df_Violatn_frequency_2016,df_Violatn_frequency_2017)

ggplot(df_Violatn_frequency, aes(x= as.factor(Violation_Code), y=Number_Of_Violation))+ facet_grid(~Issue_Date_yr) + geom_col() + xlab("Voilation Code") + ylab("Number_Of_Violation") + ggtitle("Displays the frequency of the top five violation codes for each year.")+ geom_text(aes(label=Number_Of_Violation),vjust=-0.3)

#--------------------------------------------------------------------------------
#--------------------------------------------------------------------------------
#2. How often does each 'vehicle body type' get a parking ticket? 
#  How about the 'vehicle make'? (Hint: find the top 5 for both)

Vechile_body_type_2015 <- SparkR::sql("SELECT Issue_Date_yr,`Vehicle Body Type` Vehicle_Body_Type, count(`Vehicle Body Type`) Number_Of_Violation FROM final_dat2015 group by Issue_Date_yr,Vehicle_Body_Type order by  Number_Of_Violation desc limit 5 ")

df_Vechile_body_type_2015<- data.frame(head(Vechile_body_type_2015, nrow(Vechile_body_type_2015)))

df_Vechile_body_type_2015
#---------
Vechile_body_type_2016 <- SparkR::sql("SELECT Issue_Date_yr,`Vehicle Body Type` Vehicle_Body_Type, count(`Vehicle Body Type`) Number_Of_Violation FROM final_dat2016 group by Issue_Date_yr,Vehicle_Body_Type order by  Number_Of_Violation desc limit 5 ")

df_Vechile_body_type_2016<- data.frame(head(Vechile_body_type_2016, nrow(Vechile_body_type_2016)))

df_Vechile_body_type_2016
#---------
Vechile_body_type_2017 <- SparkR::sql("SELECT Issue_Date_yr,`Vehicle Body Type` Vehicle_Body_Type, count(`Vehicle Body Type`) Number_Of_Violation FROM final_dat2017 group by Issue_Date_yr,Vehicle_Body_Type order by  Number_Of_Violation desc limit 5 ")

df_Vechile_body_type_2017<- data.frame(head(Vechile_body_type_2017, nrow(Vechile_body_type_2017)))

df_Vechile_body_type_2017
#---------
df_Vechile_body_type <- rbind(df_Vechile_body_type_2015,df_Vechile_body_type_2016,df_Vechile_body_type_2017)
#--------
ggplot(df_Vechile_body_type, aes(x= as.factor(Vehicle_Body_Type), y=Number_Of_Violation))+ facet_grid(~Issue_Date_yr) + geom_col() + xlab("Vehicle Body Type") + ylab("Number_Of_Violation") + ggtitle("Displays How often does each 'vehicle body type' get a parking ticket - Top 5 for every year")+ geom_text(aes(label=Number_Of_Violation),vjust=-0.3)

#--------------------------------------------------------------------------------
#  How about the 'vehicle make'? (Hint: find the top 5 for both)

Vechile_maker_2015 <- SparkR::sql("SELECT Issue_Date_yr,`vehicle make` Vehicle_Maker, count(`vehicle make`) Number_Of_Violation FROM final_dat2015 group by Issue_Date_yr,Vehicle_Maker order by  Number_Of_Violation desc limit 5 ")

df_Vechile_maker_2015<- data.frame(head(Vechile_maker_2015, nrow(Vechile_maker_2015)))

df_Vechile_maker_2015
#----------------
Vechile_maker_2016 <- SparkR::sql("SELECT Issue_Date_yr,`vehicle make` Vehicle_Maker, count(`vehicle make`) Number_Of_Violation FROM final_dat2016 group by Issue_Date_yr,Vehicle_Maker order by  Number_Of_Violation desc limit 5 ")

df_Vechile_maker_2016<- data.frame(head(Vechile_maker_2016, nrow(Vechile_maker_2016)))

df_Vechile_maker_2016
#----------------
Vechile_maker_2017 <- SparkR::sql("SELECT Issue_Date_yr,`vehicle make` Vehicle_Maker, count(`vehicle make`) Number_Of_Violation FROM final_dat2017 group by Issue_Date_yr,Vehicle_Maker order by  Number_Of_Violation desc limit 5 ")

df_Vechile_maker_2017<- data.frame(head(Vechile_maker_2017, nrow(Vechile_maker_2017)))

df_Vechile_maker_2017

df_Vechile_maker <- rbind(df_Vechile_maker_2015,df_Vechile_maker_2016,df_Vechile_maker_2017)
#--------
ggplot(df_Vechile_maker, aes(x= as.factor(Vehicle_Maker), y=Number_Of_Violation))+ facet_grid(~Issue_Date_yr) + geom_col() + xlab("Vehicle Maker") + ylab("Number_Of_Violation") + ggtitle("Displays How often does each 'vehicle maker' get a parking ticket - Top 5 for every year")+ geom_text(aes(label=Number_Of_Violation),vjust=-0.3)

#--------------------------------------------------------------------------------
#--------------------------------------------------------------------------------
#3. A precinct is a police station that has a certain zone of the city under 
#     its command. Find the (5 highest) frequency of tickets for each of the 
#     following:

#  'Violation Precinct' (this is the precinct of the zone where the violation 
#   occurred). Using this, can you make any insights for parking violations 
#   in any specific areas of the city?

#  'Issuer Precinct' (this is the precinct that issued the ticket)
# Here you would have noticed that the dataframe has 'Violating Precinct' 
# or 'Issuing Precinct' as '0'. These are the erroneous entries. Hence, 
#provide the record for five correct precincts. 
#(Hint: print top six entries after sorting)

Violation_Precinct_2015 <- SparkR::sql("SELECT Issue_Date_yr,`Violation Precinct` Violation_Precinct, count(`Violation Precinct`) Number_Of_Violation FROM final_dat2015 group by Issue_Date_yr,Violation_Precinct order by Number_Of_Violation desc limit 6 ")

df_Violation_Precinct_2015 <- data.frame(head(Violation_Precinct_2015, nrow(Violation_Precinct_2015)))

df_Violation_Precinct_2015
#-----------
Violation_Precinct_2016 <- SparkR::sql("SELECT Issue_Date_yr,`Violation Precinct` Violation_Precinct, count(`Violation Precinct`) Number_Of_Violation FROM final_dat2016 group by Issue_Date_yr,Violation_Precinct order by Number_Of_Violation desc limit 6 ")

df_Violation_Precinct_2016 <- data.frame(head(Violation_Precinct_2016, nrow(Violation_Precinct_2016)))

df_Violation_Precinct_2016
#-----------
Violation_Precinct_2017 <- SparkR::sql("SELECT Issue_Date_yr,`Violation Precinct` Violation_Precinct, count(`Violation Precinct`) Number_Of_Violation FROM final_dat2017 group by Issue_Date_yr,Violation_Precinct order by Number_Of_Violation desc limit 6 ")

df_Violation_Precinct_2017 <- data.frame(head(Violation_Precinct_2017, nrow(Violation_Precinct_2017)))

df_Violation_Precinct_2017

df_Violation_Precinct <- rbind(df_Violation_Precinct_2015,df_Violation_Precinct_2016,df_Violation_Precinct_2017)
#-----------
ggplot(df_Violation_Precinct, aes(x= as.factor(Violation_Precinct), y=Number_Of_Violation))+ facet_grid(~Issue_Date_yr) + geom_col() + xlab("Vehicle Precinct") + ylab("Number_Of_Violation") + ggtitle("Displays 'Violation Precinct' area - Top 5 for every year")+ geom_text(aes(label=Number_Of_Violation),vjust=-0.3)
#--------------------------------------------------------------------------------
# 2. 'Issuer Precinct' (this is the precinct that issued the ticket)

Issuer_Precinct_2015 <- SparkR::sql("SELECT Issue_Date_yr,`Issuer Precinct` Issuer_Precinct, count(`Issuer Precinct`) Number_Of_Violation FROM final_dat2015 group by Issue_Date_yr,Issuer_Precinct order by Number_Of_Violation desc limit 6 ")

df_Issuer_Precinct_2015 <- data.frame(head(Issuer_Precinct_2015, nrow(Issuer_Precinct_2015)))

df_Issuer_Precinct_2015
#------
Issuer_Precinct_2016 <- SparkR::sql("SELECT Issue_Date_yr,`Issuer Precinct` Issuer_Precinct, count(`Issuer Precinct`) Number_Of_Violation FROM final_dat2016 group by Issue_Date_yr,Issuer_Precinct order by Number_Of_Violation desc limit 6 ")

df_Issuer_Precinct_2016 <- data.frame(head(Issuer_Precinct_2016, nrow(Issuer_Precinct_2016)))

df_Issuer_Precinct_2016
#------
Issuer_Precinct_2017 <- SparkR::sql("SELECT Issue_Date_yr,`Issuer Precinct` Issuer_Precinct, count(`Issuer Precinct`) Number_Of_Violation FROM final_dat2017 group by Issue_Date_yr,Issuer_Precinct order by Number_Of_Violation desc limit 6 ")

df_Issuer_Precinct_2017 <- data.frame(head(Issuer_Precinct_2017, nrow(Issuer_Precinct_2017)))

df_Issuer_Precinct_2017

df_Issuer_Precinct <- rbind(df_Issuer_Precinct_2015,df_Issuer_Precinct_2016,df_Issuer_Precinct_2017)
#-----------
ggplot(df_Issuer_Precinct, aes(x= as.factor(Issuer_Precinct), y=Number_Of_Violation))+ facet_grid(~Issue_Date_yr) + geom_col() + xlab("Issuer Precinct") + ylab("Number_Of_Violation") + ggtitle("Displays 'Issuer Precinct' area - Top 5 for every year")+ geom_text(aes(label=Number_Of_Violation),vjust=-0.3)

#--------------------------------------------------------------------------------
#--------------------------------------------------------------------------------
# 4. Find the violation code frequency across three precincts which have issued 
#     the most number of tickets - do these precinct zones have an exceptionally
#     high frequency of certain violation codes? Are these codes common across 
#     precincts? 

#    Hint: You can analyse the three precincts together using the 'union all' 
# attribute in SQL view. In the SQL view, use the 'where' attribute to filter 
# among three precincts and combine them using 'union all'.
ggplot(df_Issuer_Precinct, aes(x= as.factor(Issuer_Precinct), y=sum(Number_Of_Violation))) + geom_col() + geom_text(aes(label=Number_Of_Violation),vjust=-0.1)
#----------------------------------------------------------------------------
#Top 3 precincts as per the above analysis considered for this questions as follows
# 14, 18, 19
Violation_code <- SparkR::sql("select row_number() over (partition by Issuer_Precinct order by Number_Of_Violation desc) Rnk,* from (
select Issuer_Precinct,Violation_Code,count(1) Number_Of_Violation
from (
                              SELECT `Issuer Precinct` Issuer_Precinct,`Violation Code` Violation_Code 
                              FROM final_dat2015 where `Issuer Precinct` in (19,18,14)
                              union all
                              SELECT `Issuer Precinct`,`Violation Code` 
                              FROM final_dat2016 where `Issuer Precinct` in (19,18,14)
                              union all
                              SELECT `Issuer Precinct`,`Violation Code` 
                              FROM final_dat2017 where `Issuer Precinct` in (19,18,14)
) a
                              group by Issuer_Precinct,Violation_Code) abc")


df_Violation_code <- data.frame(head(Violation_code, nrow(Violation_code)))

library(dplyr)
df_Violation_code %>% filter(Rnk < 4)

ggplot(df_Violation_code %>% filter(Rnk < 4), aes(x= as.factor(Violation_Code), y=sum(Number_Of_Violation))) + geom_col() + facet_grid(~Issuer_Precinct) + geom_col() + xlab("Issuer Precinct") + ylab("Violation_Code") + ggtitle("Displays  violation code frequency across three precincts for all the years")+ geom_text(aes(label=Number_Of_Violation),vjust=-0.3)

#--------------------------------------------------------------------------------
#--------------------------------------------------------------------------------
#5. You’d want to find out the properties of parking violations across different times of the day:
#  Find a way to deal with missing values, if any.
#Hint: Check for the null values using 'isNull' under the SQL. Also, to remove the null values, check the 'dropna' command in the API documentation.

#The Violation Time field is specified in a strange format. Find a way to make this into a time attribute that you can use to divide into groups.

#Divide 24 hours into six equal discrete bins of time. The intervals you choose are at your discretion. For each of these groups, find the three most commonly occurring violations.
#Hint: Use the CASE-WHEN in SQL view to segregate into bins. For finding the most commonly occurring violations, a similar approach can be used as mention in the hint for question 4.

#Now, try another direction. For the 3 most commonly occurring violation codes, find the most common time of the day (in terms of the bins from the previous part)

NA_ViolationTime<- SparkR::sql("SELECT count(*)as Total_Number_Of_Rows, 
                                     SUM(CASE WHEN `Violation Time` is NULL
                                     THEN 1 ELSE 0 END)as NA_Violation_Time,
                                     100*SUM(CASE WHEN `Violation Time` IS NULL
                                     THEN 1 ELSE 0 END)/count(*) as Percent_of_Tickets_ViolationTimeMissing
                                     from (select `Violation Time` from final_dat2015
                                    union all
                                    select `Violation Time` from final_dat2016
                                    union all
                                    select `Violation Time` from final_dat2017) a")

vt_2015<- subset(final_dat2015, isNotNull(final_dat2015$`Violation Time`))

vt_2015$Violation_Hour <- substr(vt_2015$`Violation Time`, 1, 2)
vt_2015$Violation_Minute <- substr(vt_2015$`Violation Time`, 4, 5)
vt_2015$Violation_AMPM <- substr(vt_2015$`Violation Time`, 6, 7)

createOrReplaceTempView(vt_2015, "vt_2015")

#Divide 24 hours into 6 equal discrete bins of time
violation_hour_bin_2015 <- SparkR::sql("SELECT Violation_Hour,
                                       `Violation Code`,
                                       CASE WHEN Violation_Hour BETWEEN 0 AND 3
                                       THEN '0_3'
                                       WHEN Violation_Hour BETWEEN 4 AND 7
                                       THEN '4_7'
                                       WHEN Violation_Hour BETWEEN 8 AND 11
                                       THEN '8_11'
                                       WHEN Violation_Hour BETWEEN 12 AND 15
                                       THEN '12_15' 
                                       WHEN Violation_Hour BETWEEN 16 AND 19
                                       THEN '16_19' 
                                       WHEN Violation_Hour BETWEEN 20 AND 23
                                       THEN '20_23' 
                                       END AS Violation_Hour_Bin_Value
                                       FROM vt_2015")

createOrReplaceTempView(violation_hour_bin_2015, "violation_hour_bin_2015")

ds_Violation_Hour_Bin_2015 <- SparkR::sql("SELECT Violation_Hour_Bin_Value,
                                  Violation_Code,
                                          Number_Of_Violation
                                          FROM (SELECT Violation_Hour_Bin_Value,
                                          Violation_Code,
                                          Number_Of_Violation,
                                          dense_rank() over (partition by Violation_Hour_Bin_Value order by Number_Of_Violation desc) Rnk
                                          FROM (SELECT Violation_Hour_Bin_Value,
                                          `Violation Code` Violation_Code,
                                          count(*)as Number_Of_Violation
                                          FROM violation_hour_bin_2015
                                          GROUP BY Violation_Hour_Bin_Value,
                                          `Violation Code`))
                                          WHERE Rnk <= 3")

df_Violation_Hour_Bin_2015 <- data.frame(head(ds_Violation_Hour_Bin_2015, nrow(ds_Violation_Hour_Bin_2015)))

ggplot(df_Violation_Hour_Bin_2015, aes(x= as.factor(Violation_Code), y=Number_Of_Violation))+ geom_col()+ facet_grid(~Violation_Hour_Bin_Value) + xlab("Violation Code") + ylab("Number Of Violation") + ggtitle("Parking violations across different times of the day - 2015") + geom_text(aes(label=Number_Of_Violation, angle=90),vjust=-0.3)+theme(axis.text.x=element_text(angle=90,hjust=1,vjust=0.5))
#---------------------------------------
vt_2016<- subset(final_dat2016, isNotNull(final_dat2016$`Violation Time`))

vt_2016$Violation_Hour <- substr(vt_2016$`Violation Time`, 1, 2)
vt_2016$Violation_Minute <- substr(vt_2016$`Violation Time`, 4, 5)
vt_2016$Violation_AMPM <- substr(vt_2016$`Violation Time`, 6, 7)

createOrReplaceTempView(vt_2016, "vt_2016")

#Divide 24 hours into 6 equal discrete bins of time
violation_hour_bin_2016 <- SparkR::sql("SELECT Violation_Hour,
                                       `Violation Code`,
                                       CASE WHEN Violation_Hour BETWEEN 0 AND 3
                                       THEN '0_3'
                                       WHEN Violation_Hour BETWEEN 4 AND 7
                                       THEN '4_7'
                                       WHEN Violation_Hour BETWEEN 8 AND 11
                                       THEN '8_11'
                                       WHEN Violation_Hour BETWEEN 12 AND 15
                                       THEN '12_15' 
                                       WHEN Violation_Hour BETWEEN 16 AND 19
                                       THEN '16_19' 
                                       WHEN Violation_Hour BETWEEN 20 AND 23
                                       THEN '20_23' 
                                       END AS Violation_Hour_Bin_Value
                                       FROM vt_2016")

createOrReplaceTempView(violation_hour_bin_2016, "violation_hour_bin_2016")

ds_Violation_Hour_Bin_2016 <- SparkR::sql("SELECT Violation_Hour_Bin_Value,
                                          Violation_Code,
                                          Number_Of_Violation
                                          FROM (SELECT Violation_Hour_Bin_Value,
                                          Violation_Code,
                                          Number_Of_Violation,
                                          dense_rank() over (partition by Violation_Hour_Bin_Value order by Number_Of_Violation desc) Rnk
                                          FROM (SELECT Violation_Hour_Bin_Value,
                                          `Violation Code` Violation_Code,
                                          count(*)as Number_Of_Violation
                                          FROM violation_hour_bin_2016
                                          GROUP BY Violation_Hour_Bin_Value,
                                          `Violation Code`))
                                          WHERE Rnk <= 3")

df_Violation_Hour_Bin_2016 <- data.frame(head(ds_Violation_Hour_Bin_2016, nrow(ds_Violation_Hour_Bin_2016)))

ggplot(df_Violation_Hour_Bin_2016, aes(x= as.factor(Violation_Code), y=Number_Of_Violation))+ geom_col()+ facet_grid(~Violation_Hour_Bin_Value) + xlab("Violation Code") + ylab("Number Of Violation") + ggtitle("Parking violations across different times of the day - 2016") + geom_text(aes(label=Number_Of_Violation, angle=90),vjust=-0.3)+theme(axis.text.x=element_text(angle=90,hjust=1,vjust=0.5))
#---------------------------------------
vt_2017<- subset(final_dat2017, isNotNull(final_dat2017$`Violation Time`))

vt_2017$Violation_Hour <- substr(vt_2017$`Violation Time`, 1, 2)
vt_2017$Violation_Minute <- substr(vt_2017$`Violation Time`, 4, 5)
vt_2017$Violation_AMPM <- substr(vt_2017$`Violation Time`, 6, 7)

createOrReplaceTempView(vt_2017, "vt_2017")

#Divide 24 hours into 6 equal discrete bins of time
violation_hour_bin_2017 <- SparkR::sql("SELECT Violation_Hour,
                                       `Violation Code`,
                                       CASE WHEN Violation_Hour BETWEEN 0 AND 3
                                       THEN '0_3'
                                       WHEN Violation_Hour BETWEEN 4 AND 7
                                       THEN '4_7'
                                       WHEN Violation_Hour BETWEEN 8 AND 11
                                       THEN '8_11'
                                       WHEN Violation_Hour BETWEEN 12 AND 15
                                       THEN '12_15' 
                                       WHEN Violation_Hour BETWEEN 16 AND 19
                                       THEN '16_19' 
                                       WHEN Violation_Hour BETWEEN 20 AND 23
                                       THEN '20_23' 
                                       END AS Violation_Hour_Bin_Value
                                       FROM vt_2017")

createOrReplaceTempView(violation_hour_bin_2017, "violation_hour_bin_2017")

ds_Violation_Hour_Bin_2017 <- SparkR::sql("SELECT Violation_Hour_Bin_Value,
                                          Violation_Code,
                                          Number_Of_Violation
                                          FROM (SELECT Violation_Hour_Bin_Value,
                                          Violation_Code,
                                          Number_Of_Violation,
                                          dense_rank() over (partition by Violation_Hour_Bin_Value order by Number_Of_Violation desc) Rnk
                                          FROM (SELECT Violation_Hour_Bin_Value,
                                          `Violation Code` Violation_Code,
                                          count(*)as Number_Of_Violation
                                          FROM violation_hour_bin_2017
                                          GROUP BY Violation_Hour_Bin_Value,
                                          `Violation Code`))
                                          WHERE Rnk <= 3")

df_Violation_Hour_Bin_2017 <- data.frame(head(ds_Violation_Hour_Bin_2017, nrow(ds_Violation_Hour_Bin_2017)))

ggplot(df_Violation_Hour_Bin_2017, aes(x= as.factor(Violation_Code), y=Number_Of_Violation))+ geom_col()+ facet_grid(~Violation_Hour_Bin_Value) + xlab("Violation Code") + ylab("Number Of Violation") + ggtitle("Parking violations across different times of the day - 2017") + geom_text(aes(label=Number_Of_Violation, angle=90),vjust=-0.3)+theme(axis.text.x=element_text(angle=90,hjust=1,vjust=0.5))
#---------------------------------------
#--------------------------------------------------------------------------------
#--------------------------------------------------------------------------------
#6. Let’s try and find some seasonality in this data

#First, divide the year into some number of seasons, and find frequencies 
#of tickets for each season. (Hint: Use Issue Date to segregate into seasons)

#Then, find the three most common violations for each of these seasons.
#(Hint: A similar approach can be used as mention in the hint for question 4.)

Season_Bin_2015 <- SparkR::sql("SELECT Issue_Date_yr,`Summons Number` Summons_Number,
                                   `Violation Code` Violation_Code,
                                   CASE WHEN Issue_Date_mm IN (1,2,12)
                                   THEN 'Winter'
                                   WHEN Issue_Date_mm BETWEEN 3 AND 5
                                   THEN 'Spring'
                                   WHEN Issue_Date_mm BETWEEN 6 AND 8
                                   THEN 'Summer'
                                   WHEN Issue_Date_mm BETWEEN 9 AND 12
                                   THEN 'Fall' 
                                   END AS Season
                                   FROM final_dat2015")

createOrReplaceTempView(Season_Bin_2015, "Season_Bin_2015")

ds_Season_Bin_2015<- SparkR::sql("SELECT Issue_Date_yr,Season,
                             Count(1) Number_Of_Violation
                             FROM Season_Bin_2015
                             GROUP BY Issue_Date_yr,Season
                             ORDER BY Number_Of_Violation desc")

df_ds_Season_Bin_2015 <- data.frame(head(ds_Season_Bin_2015, nrow(ds_Season_Bin_2015)))

df_ds_Season_Bin_2015
#---------------------------------
Season_Bin_2016 <- SparkR::sql("SELECT Issue_Date_yr,`Summons Number` Summons_Number,
                                   `Violation Code` Violation_Code,
                               CASE WHEN Issue_Date_mm IN (1,2,12)
                               THEN 'Winter'
                               WHEN Issue_Date_mm BETWEEN 3 AND 5
                               THEN 'Spring'
                               WHEN Issue_Date_mm BETWEEN 6 AND 8
                               THEN 'Summer'
                               WHEN Issue_Date_mm BETWEEN 9 AND 12
                               THEN 'Fall' 
                               END AS Season
                               FROM final_dat2016")

createOrReplaceTempView(Season_Bin_2016, "Season_Bin_2016")

ds_Season_Bin_2016<- SparkR::sql("SELECT Issue_Date_yr,Season,
                             Count(1) Number_Of_Violation
                             FROM Season_Bin_2016
                             GROUP BY Issue_Date_yr,Season
                             ORDER BY Number_Of_Violation desc")

df_ds_Season_Bin_2016 <- data.frame(head(ds_Season_Bin_2016, nrow(ds_Season_Bin_2016)))

df_ds_Season_Bin_2016
#---------------------------------
Season_Bin_2017 <- SparkR::sql("SELECT Issue_Date_yr,`Summons Number` Summons_Number,
                                   `Violation Code` Violation_Code,
                               CASE WHEN Issue_Date_mm IN (1,2,12)
                               THEN 'Winter'
                               WHEN Issue_Date_mm BETWEEN 3 AND 5
                               THEN 'Spring'
                               WHEN Issue_Date_mm BETWEEN 6 AND 8
                               THEN 'Summer'
                               WHEN Issue_Date_mm BETWEEN 9 AND 12
                               THEN 'Fall' 
                               END AS Season
                               FROM final_dat2017")

createOrReplaceTempView(Season_Bin_2017, "Season_Bin_2017")

ds_Season_Bin_2017<- SparkR::sql("SELECT Issue_Date_yr,Season,
                             Count(1) Number_Of_Violation
                             FROM Season_Bin_2017
                             GROUP BY Issue_Date_yr,Season
                             ORDER BY Number_Of_Violation desc")

df_ds_Season_Bin_2017 <- data.frame(head(ds_Season_Bin_2017, nrow(ds_Season_Bin_2017)))

df_ds_Season_Bin_2017

df_ds_Season_Bin <- rbind(df_ds_Season_Bin_2015,df_ds_Season_Bin_2016,df_ds_Season_Bin_2017)

ggplot(df_ds_Season_Bin, aes(x= as.factor(Season), y=Number_Of_Violation))+ geom_col()+ facet_grid(~Issue_Date_yr) + xlab("Season Bin") + ylab("Number Of Violation") + ggtitle("Frequencies of tickets for each season") + geom_text(aes(label=Number_Of_Violation, angle=90),vjust=-0.3)+theme(axis.text.x=element_text(angle=90,hjust=1,vjust=0.5))

#---------------------------------

#Then, find the three most common violations for each of these seasons.
#(Hint: A similar approach can be used as mention in the hint for question 4.)

Season_Violation_Bin <- SparkR::sql("SELECT Issue_Date_yr,`Summons Number` Summons_Number,
                               `Violation Code` Violation_Code,
                                    CASE WHEN Issue_Date_mm IN (1,2,12)
                                    THEN 'Winter'
                                    WHEN Issue_Date_mm BETWEEN 3 AND 5
                                    THEN 'Spring'
                                    WHEN Issue_Date_mm BETWEEN 6 AND 8
                                    THEN 'Summer'
                                    WHEN Issue_Date_mm BETWEEN 9 AND 12
                                    THEN 'Fall' 
                                    END AS Season
                                    FROM (
                                    select Issue_Date_yr,Issue_Date_mm,`Summons Number`,`Violation Code` from final_dat2015
                                    union all
                                    select Issue_Date_yr,Issue_Date_mm,`Summons Number`,`Violation Code` from final_dat2016
                                    union all
                                    select Issue_Date_yr,Issue_Date_mm,`Summons Number`,`Violation Code` from final_dat2017
                                    ) abc")

createOrReplaceTempView(Season_Violation_Bin, "Season_Violation_Bin")

ds_Season_Violation_Bin<- SparkR::sql("select row_number() over (partition by Season order by Number_Of_Violation desc) Rnk,* from (
SELECT Violation_Code,Season,
                                 Count(1) Number_Of_Violation
                                 FROM Season_Violation_Bin
                                 GROUP BY Violation_Code,Season
                                 ORDER BY Number_Of_Violation desc)abc")

df_Season_Violation_Bin <- data.frame(head(ds_Season_Violation_Bin, nrow(ds_Season_Violation_Bin)))

df_Season_Violation_Bin

library(dplyr)
df_Season_Violation_Bin %>% filter(Rnk < 4)
#---------------------------------
library(ggplot2)
ggplot(df_Season_Violation_Bin %>% filter(Rnk < 4), aes(x= as.factor(Violation_Code), y=Number_Of_Violation))+ geom_col()+ facet_grid(~Season) + xlab("Violation_Code") + ylab("Number Of Violation") + ggtitle("The three most common violations for each of these seasons") + geom_text(aes(label=Number_Of_Violation, angle=90),vjust=-0.3)+theme(axis.text.x=element_text(angle=90,hjust=1,vjust=0.5))

#--------------------------------------------------------------------------------
#--------------------------------------------------------------------------------
#The fines collected from all the parking violation constitute a revenue source for the NYC police department. Let’s take an example of estimating that for the three most commonly occurring codes.
#Find total occurrences of the three most common violation codes
#Then, visit the website:
#  http://www1.nyc.gov/site/finance/vehicles/services-violation-codes.page
#It lists the fines associated with different violation codes. They’re divided into two categories, one for the highest-density locations of the city, the other for the rest of the city. For simplicity, take an average of the two.
#Using this information, find the total amount collected for the three violation codes with maximum tickets. State the code which has the highest total collection.
#What can you intuitively infer from these findings?
  
Violation_code <- SparkR::sql("SELECT Issue_Date_yr,`Violation Code` Violation_Code , 
                             case when `Violation Code` = 21
                            then count(`Violation Code`) * ((65+45)/2)
                             when `Violation Code` = 36
                             then count(`Violation Code`) * ((50+50)/2) 
                             when `Violation Code` = 38
                             then count(`Violation Code`) * ((65+35)/2) 
                             end total_collection
                              FROM (select Issue_Date_yr,`Violation Code` from final_dat2015
                                      union all
                                      select Issue_Date_yr,`Violation Code` from final_dat2016
                                      union all
                                      select Issue_Date_yr,`Violation Code` from final_dat2017
                                      ) 
                              where `Violation Code` in (21,36,38)
                              group by Issue_Date_yr,`Violation Code`  
                               order by total_collection desc  ")

df_Violation_code <- data.frame(head(Violation_code, nrow(Violation_code)))

df_Violation_code
#---------------------------------
library(ggplot2)
ggplot(df_Violation_code, aes(x= as.factor(Violation_Code), y=total_collection))+ geom_col()+ facet_grid(~Issue_Date_yr) + xlab("Violation_Code") + ylab("total_collection") + ggtitle("Total amount collected for the three violation codes with maximum tickets") + geom_text(aes(label=total_collection, angle=90),vjust=-0.3)+theme(axis.text.x=element_text(angle=90,hjust=1,vjust=0.5))

#--------------------------------------------------------------------------------
#--------------------------------------------------------------------------------
#--------------------------------------------------------------------------------
